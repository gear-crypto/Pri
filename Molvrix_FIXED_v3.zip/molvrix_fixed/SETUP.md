# MOLVRIX — Setup Guide
## Complete step-by-step for Supabase + Razorpay + OAuth

---

## 1. Supabase Setup

### 1a. Create project
1. Go to https://supabase.com → New Project
2. Note your **Project URL** and **anon key** (Settings → API)

### 1b. Run the schema
1. Go to **SQL Editor** → New Query
2. Paste the full contents of `supabase-schema.sql`
3. Click **Run**

### 1c. Set your credentials
Open `js/config.js` and replace:
```js
supabase: {
  url:     'https://YOUR_PROJECT.supabase.co',   // ← your project URL
  anonKey: 'YOUR_SUPABASE_ANON_KEY',             // ← your anon key
}
```

Also update `api/razorpay-order.php` and `api/razorpay-verify.php`:
```php
define('SUPABASE_URL',        'https://YOUR_PROJECT.supabase.co');
define('SUPABASE_SERVICE_KEY','YOUR_SUPABASE_SERVICE_ROLE_KEY'); // Settings → API → service_role
```

### 1d. Make yourself admin
After signing up at `/login.html`, go to Supabase **SQL Editor** and run:
```sql
SELECT make_admin('your@email.com');
```

---

## 2. OAuth Providers (Google, Microsoft, Twitter, Facebook)

### All providers:
1. Go to **Supabase Dashboard → Authentication → Providers**
2. Add your redirect URL: `https://molvrix.com/auth-callback.html`

### Google
1. Go to https://console.cloud.google.com → APIs & Services → Credentials
2. Create OAuth 2.0 Client ID (Web application)
3. Add `https://YOUR_PROJECT.supabase.co/auth/v1/callback` as authorized redirect URI
4. Paste Client ID + Secret in Supabase → Auth → Google

### Microsoft
1. Go to https://portal.azure.com → App registrations → New registration
2. Add redirect URI: `https://YOUR_PROJECT.supabase.co/auth/v1/callback`
3. Paste Application (client) ID + secret in Supabase → Auth → Azure

### Twitter / X
1. Go to https://developer.twitter.com → Apps → New App
2. Enable OAuth 2.0, add callback URL: `https://YOUR_PROJECT.supabase.co/auth/v1/callback`
3. Paste API key + secret in Supabase → Auth → Twitter

### Facebook
1. Go to https://developers.facebook.com → My Apps → New App
2. Add Facebook Login → Settings → Valid OAuth Redirect URIs:
   `https://YOUR_PROJECT.supabase.co/auth/v1/callback`
3. Paste App ID + App Secret in Supabase → Auth → Facebook

---

## 3. Razorpay Setup

1. Sign up at https://dashboard.razorpay.com
2. Go to **Settings → API Keys → Generate Key**
3. Update `js/config.js`:
```js
razorpay: {
  keyId: 'rzp_test_YOUR_KEY_ID',  // ← paste here
  ...
}
```
4. Update `api/razorpay-order.php` and `api/razorpay-verify.php`:
```php
define('RAZORPAY_KEY_ID',     'rzp_test_YOUR_KEY_ID');
define('RAZORPAY_KEY_SECRET', 'YOUR_SECRET_HERE');
```
5. Switch to `rzp_live_...` when going live

---

## 4. Add Products

### Option A — Admin Panel (recommended)
1. Go to `/admin/panel.html`
2. Sign in with your admin email
3. Click **Products → + Add Product**
4. Fill in all fields including the **Download URL** (Supabase Storage link or external)

### Option B — Edit data/products.json
Products are also cached in `data/products.json`.
The site fetches from `api/products.php` which reads from Supabase first, fallback to the JSON file.

---

## 5. Supabase Storage (for product files)

1. Go to **Supabase → Storage → New Bucket** → name: `products`, set to **private**
2. Upload your product ZIP files
3. Create a signed URL (valid for X days) or use the download API
4. Paste the URL into the product's **Download URL** field in admin

---

## 6. Newsletter (Mailchimp/ConvertKit)

Open `js/nav.js` and find `WEBHOOK_URL`:
```js
const WEBHOOK_URL = 'https://hooks.zapier.com/hooks/catch/...'; // ← your webhook
```

**Using Zapier:**
1. Create Zap: Webhook → Mailchimp (Add/Update Subscriber)
2. Map `email` field → Mailchimp list
3. Paste the Zapier webhook URL above

**Using Make.com (formerly Integromat):**
1. Create scenario: Custom Webhook → Mailchimp
2. Same mapping, paste URL above

---

## 7. Coupon Codes

Manage coupons via:
- **Admin Panel → Coupons → + New Coupon**
- They are stored in Supabase and validated server-side in `api/razorpay-order.php`

The frontend also has a local cache in `cart.js` for instant UI feedback.

---

## 8. Affiliates

1. Admin Panel → Affiliates → + Add Affiliate
2. Give them their code (e.g. `JOHNDOE30`)
3. They share: `https://molvrix.com/?ref=JOHNDOE30`
4. The `?ref=` param is stored in localStorage and sent with every order to `razorpay-verify.php`

Track commissions in Supabase → `affiliates` table.

---

## 9. Checklist before going live

- [ ] Replace all `YOUR_*` in `js/config.js`
- [ ] Replace all `YOUR_*` in `api/razorpay-order.php`
- [ ] Replace all `YOUR_*` in `api/razorpay-verify.php`
- [ ] Run `supabase-schema.sql` in your Supabase project
- [ ] Run `SELECT make_admin('your@email.com');`
- [ ] Enable OAuth providers in Supabase dashboard
- [ ] Switch Razorpay from `rzp_test_` to `rzp_live_`
- [ ] Upload product files to Supabase Storage
- [ ] Add Download URLs to each product in Admin Panel
- [ ] Set `WEBHOOK_URL` in `nav.js` for newsletter
- [ ] Update `hello@molvrix.com` in `api/contact.php`

---

## File Map

```
molvrix/
├── js/
│   ├── config.js          ← ALL your API keys go here
│   ├── auth.js            ← Supabase OAuth (all providers)
│   ├── cart.js            ← Cart (digital products, qty=1)
│   ├── nav.js             ← Header + footer + newsletter
│   └── illustrations.js   ← SVG art for product cards
├── api/
│   ├── razorpay-order.php  ← Creates Razorpay order
│   ├── razorpay-verify.php ← Verifies + records payment
│   ├── contact.php         ← Contact form
│   ├── products.php        ← Products API (reads Supabase → JSON fallback)
│   └── blogs.php           ← Blogs API
├── admin/
│   └── panel.html          ← Full Supabase-powered admin SPA
├── supabase-schema.sql     ← Run this in Supabase SQL Editor
├── SETUP.md                ← This file
└── ...pages
```
