<?php
require_once __DIR__ . '/admin-auth.php';
require_once 'csrf.php';
$products = json_decode(file_get_contents(__DIR__.'/../data/products.json'), true) ?: [];
$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Products — MOLVRIX Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Space+Mono:wght@400;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style><?php include 'admin-styles.php'; ?></style>
</head>
<body>
<?php include 'admin-nav.php'; ?>
<div class="admin-layout">
    <?php include 'admin-sidebar.php'; ?>
    <main class="admin-main">
        <div class="admin-header">
            <div>
                <p class="admin-comment">// <?= count($products) ?> products total</p>
                <h1>All Products</h1>
            </div>
            <a href="add-product.php" class="btn-green">+ Add Product</a>
        </div>
        <?php if ($msg): ?><div class="alert alert-success">✓ <?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <div class="table-wrap">
            <table class="admin-table">
                <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Badge</th><th>Download</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach($products as $p): ?>
                <tr>
                    <td><span class="table-icon"><?= $p['icon'] ?></span> <?= htmlspecialchars($p['name']) ?></td>
                    <td><span class="badge"><?= htmlspecialchars($p['category']) ?></span></td>
                    <td class="price-cell">$<?= $p['price'] ?><?= $p['originalPrice'] ? ' <span class="orig">$'.$p['originalPrice'].'</span>' : '' ?></td>
                    <td><?= $p['badge'] ? '<span class="badge">'.$p['badge'].'</span>' : '<span style="color:var(--muted)">—</span>' ?></td>
                    <td><?= !empty($p['download_url']) ? '<span style="color:var(--green);font-size:0.7rem">✓ Set</span>' : '<span style="color:var(--red);font-size:0.7rem">✗ Missing</span>' ?></td>
                    <td>
                        <a href="add-product.php?edit=<?= $p['id'] ?>" class="action-btn">Edit</a>
                        <a href="delete-product.php?id=<?= $p['id'] ?>&csrf=<?= csrf_token() ?>" class="action-btn danger" onclick="return confirm('Delete <?= htmlspecialchars($p['name']) ?>?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
</body>
</html>
