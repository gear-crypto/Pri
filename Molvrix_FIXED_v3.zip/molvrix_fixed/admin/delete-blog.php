<?php
// delete-blog.php — CSRF protected
require_once __DIR__ . '/admin-auth.php';
require_once 'csrf.php';
csrf_verify();

$id = $_GET['id'] ?? '';
$file = __DIR__.'/../data/blogs.json';
$blogs = json_decode(file_get_contents($file), true) ?: [];
$blogs = array_values(array_filter($blogs, fn($b) => $b['id'] !== $id));
file_put_contents($file, json_encode($blogs, JSON_PRETTY_PRINT));
header('Location: blogs.php?msg=Post+deleted');
