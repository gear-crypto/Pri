<?php
session_start();
require_once __DIR__ . '/../api/logger.php';

// ── Hashed password. To change: run php -r "echo password_hash('yourpassword', PASSWORD_DEFAULT);" ──
define('ADMIN_USER',     'admin');
define('ADMIN_PASS_HASH', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'); // default: "molvrix2026"

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';
    // Brute-force protection: track failed attempts per IP
    $ip       = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $atkKey   = 'admin_fail_' . md5($ip);
    $attempts = (int)($_SESSION[$atkKey . '_count'] ?? 0);
    $lastFail = (int)($_SESSION[$atkKey . '_time']  ?? 0);

    // Lock out for 15 min after 5 failures
    if ($attempts >= 5 && (time() - $lastFail) < 900) {
        $wait = 900 - (time() - $lastFail);
        MolvrixLog::write('security', 'Admin login blocked — brute-force lockout', ['ip' => $ip, 'attempts' => $attempts]);
        $errMsg = "Too many failed attempts. Try again in " . ceil($wait/60) . " minute(s).";
    } elseif ($user === ADMIN_USER && password_verify($pass, ADMIN_PASS_HASH)) {
        unset($_SESSION[$atkKey . '_count'], $_SESSION[$atkKey . '_time']);
        session_regenerate_id(true);
        $_SESSION['molvrix_admin']      = true;
        $_SESSION['admin_time']         = time();
        $_SESSION['admin_last_active']  = time();
        MolvrixLog::write('activity', 'Admin login successful', ['ip' => $ip]);
        header('Location: dashboard.php'); exit;
    } else {
        $_SESSION[$atkKey . '_count'] = $attempts + 1;
        $_SESSION[$atkKey . '_time']  = time();
        MolvrixLog::write('security', 'Admin login failed — wrong credentials', ['ip' => $ip, 'attempt' => $attempts + 1]);
        $error = 'Invalid credentials.';
    }
}

if (!empty($_SESSION['molvrix_admin'])) { header('Location: dashboard.php'); exit; }

// ── URL messages from logout / session expiry ──
$urlMsg = '';
$urlMsgType = 'info';
$msg = $_GET['msg'] ?? '';
if ($msg === 'logged_out')      { $urlMsg = '✓ You have been logged out.';           $urlMsgType = 'success'; }
if ($msg === 'session_expired') { $urlMsg = '⚠ Session expired. Please log in again.'; $urlMsgType = 'warn'; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — MOLVRIX</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Space+Mono:wght@400;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
:root{--black:#0d1117;--black-2:#0a0e14;--black-3:#161b22;--green:#2ea043;--green-2:#3fb950;--white:#f0f6fc;--muted:#8b949e;--border:rgba(48,56,66,0.8);--border-g:rgba(46,160,67,0.25);--red:#f85149}
body{font-family:'DM Mono',monospace;background:var(--black-2);color:var(--white);min-height:100vh;display:flex;align-items:center;justify-content:center;}
body::before{content:'';position:fixed;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(46,160,67,0.012) 4px);pointer-events:none}
.login-box{background:var(--black);border:1px solid var(--border);border-radius:12px;padding:3rem;width:100%;max-width:420px;position:relative;z-index:1}
.login-logo{display:flex;align-items:center;gap:6px;margin-bottom:2rem;justify-content:center}
.logo-prompt{font-family:'Space Mono',monospace;font-size:1.2rem;font-weight:700;color:var(--green)}
.logo-name{font-family:'Syne',sans-serif;font-size:1.8rem;font-weight:800;color:var(--white);letter-spacing:-0.04em}
.login-cursor{width:3px;height:24px;background:var(--green);animation:blink 1.1s step-end infinite;border-radius:1px}
@keyframes blink{50%{opacity:0}}
.login-title{font-family:'Space Mono',monospace;font-size:0.7rem;letter-spacing:0.16em;text-transform:uppercase;color:var(--muted);text-align:center;margin-bottom:2rem}
.login-title::before{content:'// ';color:var(--green);opacity:0.6}
.form-group{margin-bottom:1.2rem}
.form-label{display:block;font-family:'Space Mono',monospace;font-size:0.62rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--muted);margin-bottom:0.5rem}
.form-input{width:100%;padding:0.8rem 1rem;background:var(--black-3);color:var(--white);border:1px solid var(--border);border-radius:4px;font-family:'DM Mono',monospace;font-size:0.85rem;outline:none;transition:border-color 0.2s}
.form-input:focus{border-color:var(--border-g)}
.form-input::placeholder{color:var(--muted)}
.error{background:rgba(248,81,73,0.1);border:1px solid rgba(248,81,73,0.3);color:var(--red);padding:0.75rem 1rem;border-radius:4px;font-size:0.75rem;margin-bottom:1.2rem;font-family:'Space Mono',monospace}
.msg-success{background:rgba(46,160,67,0.1);border:1px solid rgba(46,160,67,0.3);color:var(--green);padding:0.75rem 1rem;border-radius:4px;font-size:0.75rem;margin-bottom:1.2rem;font-family:'Space Mono',monospace}
.msg-warn{background:rgba(210,153,34,0.1);border:1px solid rgba(210,153,34,0.3);color:#e3b341;padding:0.75rem 1rem;border-radius:4px;font-size:0.75rem;margin-bottom:1.2rem;font-family:'Space Mono',monospace}
.btn-login{width:100%;padding:0.9rem;background:var(--green);color:var(--black);border:none;border-radius:4px;font-family:'Space Mono',monospace;font-weight:700;font-size:0.78rem;letter-spacing:0.08em;text-transform:uppercase;cursor:pointer;transition:all 0.2s;margin-top:0.5rem}
.btn-login:hover{background:var(--green-2);transform:translateY(-2px)}
.back-link{display:block;text-align:center;margin-top:1.5rem;font-family:'Space Mono',monospace;font-size:0.65rem;color:var(--muted);text-decoration:none;transition:color 0.2s}
.back-link:hover{color:var(--green)}
.hash-hint{font-family:'Space Mono',monospace;font-size:0.58rem;color:var(--muted);text-align:center;margin-top:2rem;opacity:0.5}
</style>
</head>
<body>
<div class="login-box">
    <div class="login-logo">
        <span class="logo-prompt">$_</span>
        <span class="logo-name">MOLVRIX</span>
        <span class="login-cursor"></span>
    </div>
    <p class="login-title">Admin Access</p>
    <?php if (!empty($urlMsg)): ?>
        <div class="msg-<?= $urlMsgType ?>"><?= htmlspecialchars($urlMsg) ?></div>
    <?php endif; ?>
    <?php if (!empty($error)): ?>
        <div class="error">✗ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-input" placeholder="admin" required autocomplete="off">
        </div>
        <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-input" placeholder="••••••••" required>
        </div>
        <button type="submit" class="btn-login">$ Login →</button>
    </form>
    <a href="../index.html" class="back-link">← Back to site</a>
    <p class="hash-hint">To change password: php -r "echo password_hash('newpass', PASSWORD_DEFAULT);"</p>
</div>
</body>
</html>
