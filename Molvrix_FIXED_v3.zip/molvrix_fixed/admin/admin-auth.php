<?php
/**
 * MOLVRIX — Admin Auth Guard
 * Include at the top of every admin PHP page instead of repeating
 * the session_start + check pattern manually.
 *
 * Usage (replace the top 3 lines of each admin file):
 *   require_once __DIR__ . '/admin-auth.php';
 *
 * What it does:
 *   1. Starts session
 *   2. Checks molvrix_admin flag — redirects to login if missing
 *   3. Enforces 2-hour inactivity timeout — logs out stale sessions
 *   4. Refreshes last-activity timestamp on each page load
 */

if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../api/logger.php';

define('ADMIN_SESSION_TIMEOUT', 7200); // 2 hours inactivity

// ── Check login ──
if (empty($_SESSION['molvrix_admin'])) {
    header('Location: login.php');
    exit;
}

// ── Enforce inactivity timeout ──
$lastActive = $_SESSION['admin_last_active'] ?? 0;
if ($lastActive && (time() - $lastActive) > ADMIN_SESSION_TIMEOUT) {
    MolvrixLog::write('security', 'Admin session expired — inactivity', ['inactive_seconds' => time() - $lastActive]);
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    header('Location: login.php?msg=session_expired');
    exit;
}

// ── Refresh activity timestamp ──
$_SESSION['admin_last_active'] = time();
