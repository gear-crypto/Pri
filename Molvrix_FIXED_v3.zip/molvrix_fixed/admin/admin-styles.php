/* MOLVRIX Admin Styles */
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
:root{--black:#0d1117;--black-2:#0a0e14;--black-3:#161b22;--black-4:#21262d;--green:#2ea043;--green-2:#3fb950;--white:#f0f6fc;--white-2:#c9d1d9;--muted:#8b949e;--border:rgba(48,56,66,0.8);--border-g:rgba(46,160,67,0.25);--red:#f85149}
body{font-family:'DM Mono',monospace;background:var(--black-2);color:var(--white);min-height:100vh}
body::before{content:'';position:fixed;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(46,160,67,0.012) 4px);pointer-events:none;z-index:0}

/* Top bar */
.admin-topbar{position:fixed;top:0;width:100%;z-index:100;background:rgba(10,14,20,0.95);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);padding:0.8rem 2rem;display:flex;justify-content:space-between;align-items:center}
.topbar-logo{display:flex;align-items:center;gap:6px;text-decoration:none}
.logo-prompt{font-family:'Space Mono',monospace;font-size:0.9rem;font-weight:700;color:var(--green)}
.logo-name{font-family:'Syne',sans-serif;font-size:1.3rem;font-weight:800;color:var(--white);letter-spacing:-0.04em}
.logo-cursor{width:2px;height:17px;background:var(--green);animation:blink 1.1s step-end infinite;border-radius:1px}
@keyframes blink{50%{opacity:0}}
.topbar-badge{font-family:'Space Mono',monospace;font-size:0.62rem;background:rgba(46,160,67,0.15);color:var(--green);border:1px solid var(--border-g);padding:3px 10px;border-radius:3px;letter-spacing:0.1em}
.topbar-right{display:flex;align-items:center;gap:1rem}
.topbar-right a{font-family:'Space Mono',monospace;font-size:0.68rem;color:var(--muted);text-decoration:none;transition:color 0.2s}
.topbar-right a:hover{color:var(--white)}
.topbar-right a.logout{color:var(--red)}

/* Layout */
.admin-layout{display:flex;padding-top:57px;min-height:100vh;position:relative;z-index:1}

/* Sidebar */
.admin-sidebar{width:240px;flex-shrink:0;background:var(--black);border-right:1px solid var(--border);padding:2rem 0;position:sticky;top:57px;height:calc(100vh - 57px);overflow-y:auto}
.sidebar-section{margin-bottom:2rem}
.sidebar-section-title{font-family:'Space Mono',monospace;font-size:0.6rem;letter-spacing:0.18em;text-transform:uppercase;color:var(--muted);padding:0 1.5rem;margin-bottom:0.8rem;opacity:0.7}
.sidebar-link{display:flex;align-items:center;gap:0.8rem;padding:0.7rem 1.5rem;text-decoration:none;color:var(--muted);font-family:'Space Mono',monospace;font-size:0.72rem;transition:all 0.2s;border-left:2px solid transparent}
.sidebar-link:hover{color:var(--white);background:rgba(46,160,67,0.05)}
.sidebar-link.active{color:var(--green);border-left-color:var(--green);background:rgba(46,160,67,0.08)}
.sidebar-link-icon{font-size:1rem;width:20px;text-align:center}

/* Main */
.admin-main{flex:1;padding:2.5rem;overflow-x:auto}
.admin-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:2.5rem;flex-wrap:wrap;gap:1rem}
.admin-comment{font-family:'Space Mono',monospace;font-size:0.68rem;color:var(--green);opacity:0.55;margin-bottom:0.5rem}
.admin-header h1{font-family:'Syne',sans-serif;font-size:2rem;font-weight:800;letter-spacing:-0.02em}
.header-actions{display:flex;gap:0.8rem;align-items:center;flex-wrap:wrap}

/* Buttons */
.btn-green,.btn-outline,.btn-red{font-family:'Space Mono',monospace;font-size:0.7rem;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;padding:0.65rem 1.2rem;border-radius:4px;cursor:pointer;text-decoration:none;display:inline-block;border:none;transition:all 0.2s}
.btn-green{background:var(--green);color:var(--black)}
.btn-green:hover{background:var(--green-2);transform:translateY(-2px)}
.btn-outline{background:transparent;color:var(--white);border:1px solid var(--border)}
.btn-outline:hover{border-color:var(--border-g);color:var(--green)}
.btn-red{background:var(--red);color:var(--white)}
.btn-red:hover{opacity:0.85}

/* Stats */
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:2.5rem}
.stat-card{background:var(--black);border:1px solid var(--border);border-radius:8px;padding:1.5rem;text-align:center;transition:border-color 0.2s}
.stat-card:hover,.stat-card.green{border-color:var(--border-g)}
.stat-icon{font-size:1.5rem;margin-bottom:0.8rem}
.stat-num{font-family:'Syne',sans-serif;font-size:2rem;font-weight:800;color:var(--white);line-height:1}
.stat-card.green .stat-num{color:var(--green)}
.stat-label{font-family:'Space Mono',monospace;font-size:0.62rem;color:var(--muted);letter-spacing:0.1em;text-transform:uppercase;margin-top:0.3rem}

/* Section title */
.section-title{font-family:'Space Mono',monospace;font-size:0.68rem;font-weight:700;letter-spacing:0.16em;text-transform:uppercase;color:var(--green);margin-bottom:1rem;display:flex;align-items:center;gap:0.7rem}
.section-title::before{content:'//';opacity:0.6}

/* Quick grid */
.quick-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:1rem}
.quick-card{background:var(--black);border:1px solid var(--border);border-radius:8px;padding:1.2rem 1.4rem;display:flex;align-items:center;gap:1rem;text-decoration:none;transition:all 0.2s;cursor:pointer}
.quick-card:hover{border-color:var(--border-g);transform:translateY(-2px)}
.quick-card.danger:hover{border-color:rgba(248,81,73,0.35)}
.quick-icon{font-size:1.4rem;flex-shrink:0}
.quick-card strong{display:block;font-size:0.82rem;color:var(--white);margin-bottom:0.2rem;font-family:'Syne',sans-serif;font-weight:700}
.quick-card p{font-size:0.68rem;color:var(--muted)}
.quick-arrow{margin-left:auto;color:var(--muted);font-size:1rem;flex-shrink:0;transition:transform 0.2s}
.quick-card:hover .quick-arrow{transform:translateX(4px);color:var(--green)}

/* Table */
.table-wrap{border:1px solid var(--border);border-radius:8px;overflow:hidden;margin-bottom:0.8rem}
.admin-table{width:100%;border-collapse:collapse}
.admin-table th{background:var(--black-3);padding:0.9rem 1.2rem;text-align:left;font-family:'Space Mono',monospace;font-size:0.62rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--muted);border-bottom:1px solid var(--border)}
.admin-table td{padding:0.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:0.8rem;color:var(--white-2);vertical-align:middle}
.admin-table tr:last-child td{border-bottom:none}
.admin-table tr:hover td{background:rgba(46,160,67,0.03)}
.table-icon{margin-right:0.5rem}
.badge{background:rgba(46,160,67,0.12);color:var(--green);border:1px solid var(--border-g);padding:2px 8px;border-radius:3px;font-family:'Space Mono',monospace;font-size:0.6rem;letter-spacing:0.08em;white-space:nowrap}
.price-cell{color:var(--green);font-family:'Syne',sans-serif;font-weight:700}
.orig{color:var(--muted);text-decoration:line-through;font-size:0.7rem;margin-left:4px;font-family:'DM Mono',monospace;font-weight:400}
.date-cell{color:var(--muted);font-size:0.72rem}
.action-btn{font-family:'Space Mono',monospace;font-size:0.6rem;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;padding:3px 10px;border-radius:3px;text-decoration:none;transition:all 0.2s;border:1px solid var(--border);color:var(--white);margin-right:4px;display:inline-block}
.action-btn:hover{border-color:var(--border-g);color:var(--green)}
.action-btn.danger{color:var(--red);border-color:rgba(248,81,73,0.25)}
.action-btn.danger:hover{background:rgba(248,81,73,0.1)}
.view-all{font-family:'Space Mono',monospace;font-size:0.68rem;color:var(--muted);text-decoration:none;transition:color 0.2s}
.view-all:hover{color:var(--green)}

/* Forms */
.form-card{background:var(--black);border:1px solid var(--border);border-radius:10px;padding:2rem;margin-bottom:1.5rem}
.form-card-title{font-family:'Space Mono',monospace;font-size:0.68rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--green);margin-bottom:1.5rem;display:flex;align-items:center;gap:0.6rem}
.form-card-title::before{content:'>';opacity:0.6}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:1.2rem}
.form-group{margin-bottom:1.2rem}
.form-group.full{grid-column:1/-1}
.form-label{display:block;font-family:'Space Mono',monospace;font-size:0.62rem;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:var(--muted);margin-bottom:0.5rem}
.form-input,.form-textarea,.form-select{width:100%;padding:0.8rem 1rem;background:var(--black-3);color:var(--white);border:1px solid var(--border);border-radius:4px;font-family:'DM Mono',monospace;font-size:0.85rem;outline:none;transition:border-color 0.2s}
.form-input:focus,.form-textarea:focus,.form-select:focus{border-color:var(--border-g)}
.form-input::placeholder,.form-textarea::placeholder{color:var(--muted)}
.form-textarea{min-height:200px;resize:vertical}
.form-select{cursor:pointer}
.form-hint{font-size:0.65rem;color:var(--muted);margin-top:0.4rem;font-family:'Space Mono',monospace}
.form-actions{display:flex;gap:0.8rem;margin-top:1.5rem;padding-top:1.5rem;border-top:1px solid var(--border)}

/* Alert */
.alert{padding:0.8rem 1rem;border-radius:4px;font-family:'Space Mono',monospace;font-size:0.72rem;margin-bottom:1.5rem}
.alert-success{background:rgba(46,160,67,0.1);border:1px solid var(--border-g);color:var(--green)}
.alert-error{background:rgba(248,81,73,0.1);border:1px solid rgba(248,81,73,0.3);color:var(--red)}

/* Rich text editor */
.editor-toolbar{background:var(--black-3);border:1px solid var(--border);border-bottom:none;border-radius:4px 4px 0 0;padding:0.5rem;display:flex;gap:0.4rem;flex-wrap:wrap}
.editor-btn{background:none;border:1px solid var(--border);color:var(--white-2);padding:3px 8px;border-radius:3px;font-size:0.75rem;cursor:pointer;font-family:'Space Mono',monospace;transition:all 0.2s}
.editor-btn:hover{border-color:var(--border-g);color:var(--green)}
#contentEditor{border-radius:0 0 4px 4px;min-height:300px;border-top:1px solid var(--border)}

/* Responsive */
@media(max-width:1024px){.stats-grid{grid-template-columns:repeat(2,1fr)}.quick-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:768px){.admin-sidebar{display:none}.admin-main{padding:1.5rem}.stats-grid{grid-template-columns:repeat(2,1fr)}.quick-grid{grid-template-columns:1fr}.form-grid{grid-template-columns:1fr}}
