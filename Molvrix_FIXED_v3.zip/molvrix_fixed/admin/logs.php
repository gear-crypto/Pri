<?php
require_once __DIR__ . '/admin-auth.php';
require_once __DIR__ . '/../api/logger.php';

$category = $_GET['cat']  ?? 'all';
$days     = (int)($_GET['days'] ?? 7);
$days     = max(1, min(30, $days));

// Handle purge action
if (isset($_GET['purge']) && $_GET['purge'] === '1') {
    $deleted = MolvrixLog::purge(30);
    header('Location: logs.php?msg=purged&deleted=' . $deleted);
    exit;
}

$entries = MolvrixLog::read($category, $days, 300);
$summary = MolvrixLog::summary($days);
$total   = array_sum($summary);
$msg     = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Activity Logs — MOLVRIX Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Space+Mono:wght@400;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
<?php include 'admin-styles.php'; ?>

/* ── Logs-specific styles ── */
.log-summary { display:grid; grid-template-columns:repeat(4,1fr); gap:1rem; margin-bottom:2rem; }
.log-stat { background:var(--black-3); border:1px solid var(--border); border-radius:8px; padding:1.2rem 1.5rem; }
.log-stat-num { font-family:'Syne',sans-serif; font-size:2rem; font-weight:800; }
.log-stat-label { font-family:'Space Mono',monospace; font-size:0.6rem; text-transform:uppercase; letter-spacing:0.1em; color:var(--muted); margin-top:0.3rem; }
.log-stat.cat-payment  .log-stat-num { color:var(--green); }
.log-stat.cat-error    .log-stat-num { color:#f85149; }
.log-stat.cat-security .log-stat-num { color:#e3b341; }
.log-stat.cat-activity .log-stat-num { color:#58a6ff; }

.log-filters { display:flex; align-items:center; gap:0.75rem; margin-bottom:1.5rem; flex-wrap:wrap; }
.log-tab { font-family:'Space Mono',monospace; font-size:0.65rem; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; padding:0.4rem 1rem; border-radius:4px; border:1px solid var(--border); background:none; color:var(--muted); cursor:pointer; text-decoration:none; transition:all 0.2s; }
.log-tab:hover { border-color:var(--border-g); color:var(--white); }
.log-tab.active { background:var(--green); border-color:var(--green); color:var(--black); }
.log-tab.tab-error.active    { background:#f85149; border-color:#f85149; color:#fff; }
.log-tab.tab-security.active { background:#e3b341; border-color:#e3b341; color:#000; }
.log-tab.tab-activity.active { background:#58a6ff; border-color:#58a6ff; color:#000; }

.log-days { margin-left:auto; display:flex; align-items:center; gap:0.5rem; }
.log-days label { font-family:'Space Mono',monospace; font-size:0.6rem; color:var(--muted); }
.log-days select { background:var(--black-3); border:1px solid var(--border); color:var(--white); font-family:'Space Mono',monospace; font-size:0.65rem; padding:0.35rem 0.6rem; border-radius:4px; cursor:pointer; }

.log-table-wrap { overflow-x:auto; }
.log-table { width:100%; border-collapse:collapse; font-size:0.75rem; }
.log-table th { font-family:'Space Mono',monospace; font-size:0.55rem; font-weight:700; letter-spacing:0.1em; text-transform:uppercase; color:var(--muted); padding:0.6rem 0.75rem; text-align:left; border-bottom:1px solid var(--border); white-space:nowrap; }
.log-table td { padding:0.7rem 0.75rem; border-bottom:1px solid rgba(48,56,66,0.5); vertical-align:top; font-family:'DM Mono',monospace; color:var(--white-2); }
.log-table tr:last-child td { border-bottom:none; }
.log-table tr:hover td { background:rgba(255,255,255,0.02); }

.log-badge { display:inline-block; font-family:'Space Mono',monospace; font-size:0.55rem; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; padding:2px 7px; border-radius:3px; }
.badge-payment  { background:rgba(46,160,67,0.15);  color:var(--green); }
.badge-error    { background:rgba(248,81,73,0.15);  color:#f85149; }
.badge-security { background:rgba(227,179,65,0.15); color:#e3b341; }
.badge-activity { background:rgba(88,166,255,0.15); color:#58a6ff; }

.log-ts { font-size:0.65rem; color:var(--muted); white-space:nowrap; }
.log-msg { color:var(--white); font-size:0.78rem; }
.log-ctx { font-size:0.65rem; color:var(--muted); margin-top:0.3rem; word-break:break-all; }
.log-ip  { font-size:0.65rem; color:var(--muted); white-space:nowrap; }
.log-url { font-size:0.6rem; color:var(--muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:160px; }

.log-empty { text-align:center; padding:4rem 2rem; color:var(--muted); font-family:'Space Mono',monospace; font-size:0.75rem; }

.purge-btn { font-family:'Space Mono',monospace; font-size:0.62rem; font-weight:700; letter-spacing:0.06em; text-transform:uppercase; padding:0.4rem 1rem; border-radius:4px; border:1px solid rgba(248,81,73,0.3); background:none; color:#f85149; cursor:pointer; text-decoration:none; transition:all 0.2s; margin-left:auto; }
.purge-btn:hover { background:rgba(248,81,73,0.1); border-color:#f85149; }

.alert-success { background:rgba(46,160,67,0.1); border:1px solid rgba(46,160,67,0.3); color:var(--green); padding:0.75rem 1rem; border-radius:4px; font-family:'Space Mono',monospace; font-size:0.72rem; margin-bottom:1.5rem; }

@media(max-width:768px){
    .log-summary { grid-template-columns:1fr 1fr; }
    .log-days { margin-left:0; width:100%; }
}
</style>
</head>
<body>
<?php include 'admin-nav.php'; ?>
<div class="admin-layout">
    <?php include 'admin-sidebar.php'; ?>
    <main class="admin-main">
        <div class="admin-header">
            <div>
                <p class="admin-comment">// <?= $total ?> events in last <?= $days ?> days</p>
                <h1>Activity Logs</h1>
            </div>
            <a href="logs.php?purge=1" class="purge-btn" onclick="return confirm('Delete all logs older than 30 days?')">Purge Old Logs</a>
        </div>

        <?php if ($msg === 'purged'): ?>
            <div class="alert-success">✓ Purged <?= (int)$_GET['deleted'] ?> old log file(s).</div>
        <?php endif; ?>

        <!-- Summary cards -->
        <div class="log-summary">
            <div class="log-stat cat-payment">
                <div class="log-stat-num"><?= $summary['payment'] ?></div>
                <div class="log-stat-label">Payments</div>
            </div>
            <div class="log-stat cat-error">
                <div class="log-stat-num"><?= $summary['error'] ?></div>
                <div class="log-stat-label">Errors</div>
            </div>
            <div class="log-stat cat-security">
                <div class="log-stat-num"><?= $summary['security'] ?></div>
                <div class="log-stat-label">Security Events</div>
            </div>
            <div class="log-stat cat-activity">
                <div class="log-stat-num"><?= $summary['activity'] ?></div>
                <div class="log-stat-label">Activity</div>
            </div>
        </div>

        <!-- Filter tabs + days selector -->
        <div class="log-filters">
            <?php
            $tabs = [
                'all'      => ['label' => 'All',      'class' => ''],
                'payment'  => ['label' => 'Payments',  'class' => 'tab-payment'],
                'error'    => ['label' => 'Errors',    'class' => 'tab-error'],
                'security' => ['label' => 'Security',  'class' => 'tab-security'],
                'activity' => ['label' => 'Activity',  'class' => 'tab-activity'],
            ];
            foreach ($tabs as $key => $tab):
                $active = ($category === $key) ? 'active' : '';
            ?>
                <a href="logs.php?cat=<?= $key ?>&days=<?= $days ?>" class="log-tab <?= $tab['class'] ?> <?= $active ?>">
                    <?= $tab['label'] ?>
                </a>
            <?php endforeach; ?>

            <div class="log-days">
                <label>Last</label>
                <select onchange="window.location='logs.php?cat=<?= $category ?>&days='+this.value">
                    <?php foreach ([1,3,7,14,30] as $d): ?>
                        <option value="<?= $d ?>" <?= $days===$d?'selected':'' ?>><?= $d ?> day<?= $d>1?'s':'' ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <!-- Log entries table -->
        <div class="table-wrap log-table-wrap">
            <?php if (empty($entries)): ?>
                <div class="log-empty">
                    // No log entries found for this filter.<br>
                    Events will appear here as your site receives traffic.
                </div>
            <?php else: ?>
            <table class="log-table">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Category</th>
                        <th>Message</th>
                        <th>IP</th>
                        <th>Endpoint</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($entries as $e): ?>
                    <tr>
                        <td class="log-ts"><?= htmlspecialchars($e['ts']) ?></td>
                        <td><span class="log-badge badge-<?= htmlspecialchars($e['category']) ?>"><?= htmlspecialchars($e['category']) ?></span></td>
                        <td>
                            <div class="log-msg"><?= htmlspecialchars($e['message']) ?></div>
                            <?php if (!empty($e['context'])): ?>
                                <div class="log-ctx"><?= htmlspecialchars(json_encode($e['context'], JSON_UNESCAPED_SLASHES)) ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="log-ip"><?= htmlspecialchars($e['ip'] ?? '—') ?></td>
                        <td class="log-url" title="<?= htmlspecialchars($e['url'] ?? '') ?>"><?= htmlspecialchars($e['url'] ?? '—') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

    </main>
</div>
</body>
</html>
