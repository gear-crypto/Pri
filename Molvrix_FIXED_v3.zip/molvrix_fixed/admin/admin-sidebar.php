<?php $cur = basename($_SERVER['PHP_SELF']); ?>
<aside class="admin-sidebar">
    <div class="sidebar-section">
        <div class="sidebar-section-title">Main</div>
        <a href="dashboard.php" class="sidebar-link <?= $cur==='dashboard.php'?'active':'' ?>">
            <span class="sidebar-link-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M3 9.5L10 3l7 6.5V17a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9.5z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M8 18v-6h4v6" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg></span> Dashboard
        </a>
    </div>
    <div class="sidebar-section">
        <div class="sidebar-section-title">Products</div>
        <a href="products.php" class="sidebar-link <?= $cur==='products.php'?'active':'' ?>">
            <span class="sidebar-link-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M10 2L2 6v8l8 4 8-4V6L10 2z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M2 6l8 4 8-4M10 10v8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg></span> All Products
        </a>
        <a href="add-product.php" class="sidebar-link <?= $cur==='add-product.php'?'active':'' ?>">
            <span class="sidebar-link-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><line x1="10" y1="4" x2="10" y2="16" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><line x1="4" y1="10" x2="16" y2="10" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></span> Add Product
        </a>
    </div>
    <div class="sidebar-section">
        <div class="sidebar-section-title">Blog</div>
        <a href="blogs.php" class="sidebar-link <?= $cur==='blogs.php'?'active':'' ?>">
            <span class="sidebar-link-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M4 2h8l5 5v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><polyline points="12,2 12,7 17,7" stroke="currentColor" stroke-width="1.4"/><line x1="7" y1="11" x2="13" y2="11" stroke="currentColor" stroke-width="1.2" opacity="0.7" stroke-linecap="round"/><line x1="7" y1="14" x2="11" y2="14" stroke="currentColor" stroke-width="1.2" opacity="0.5" stroke-linecap="round"/></svg></span> All Posts
        </a>
        <a href="add-blog.php" class="sidebar-link <?= $cur==='add-blog.php'?'active':'' ?>">
            <span class="sidebar-link-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M14.5 2.5a2.12 2.12 0 0 1 3 3L6 17H3v-3L14.5 2.5z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg></span> New Post
        </a>
    </div>
    <div class="sidebar-section">
        <div class="sidebar-section-title">System</div>
        <a href="logs.php" class="sidebar-link <?= $cur==='logs.php'?'active':'' ?>">
            <span class="sidebar-link-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M3 4h14M3 8h10M3 12h12M3 16h8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg></span> Activity Logs
        </a>
    </div>
    <div class="sidebar-section">
        <div class="sidebar-section-title">Settings</div>
        <a href="settings.php" class="sidebar-link <?= $cur==='settings.php'?'active':'' ?>">
            <span class="sidebar-link-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><circle cx="10" cy="10" r="3" stroke="currentColor" stroke-width="1.4"/><path d="M10 2v2M10 16v2M2 10h2M16 10h2M4.2 4.2l1.4 1.4M14.4 14.4l1.4 1.4M4.2 15.8l1.4-1.4M14.4 5.6l1.4-1.4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg></span> Settings
        </a>
        <a href="logout.php" class="sidebar-link">
            <span class="sidebar-link-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><rect x="4" y="9" width="12" height="9" rx="2" stroke="currentColor" stroke-width="1.4"/><path d="M7 9V6a3 3 0 0 1 6 0v3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><circle cx="10" cy="13.5" r="1.2" fill="currentColor"/></svg></span> Logout
        </a>
    </div>
</aside>
