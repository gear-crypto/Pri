<div class="admin-topbar">
    <a href="dashboard.php" class="topbar-logo">
        <span class="logo-prompt">$_</span>
        <span class="logo-name">MOLVRIX</span>
        <span class="logo-cursor"></span>
        <span class="topbar-badge" style="margin-left:10px">ADMIN</span>
    </a>
    <div class="topbar-right">
        <a href="../index.html" target="_blank">View Site ↗</a>
        <a href="logout.php" class="logout">Logout</a>
    </div>
</div>
