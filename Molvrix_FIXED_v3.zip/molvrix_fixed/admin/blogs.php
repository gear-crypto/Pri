<?php
/* blogs.php */
require_once __DIR__ . '/admin-auth.php';
require_once 'csrf.php';
$blogs = json_decode(file_get_contents(__DIR__.'/../data/blogs.json'), true) ?: [];
$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Blog Posts — MOLVRIX Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Space+Mono:wght@400;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style><?php include 'admin-styles.php'; ?></style>
</head>
<body>
<?php include 'admin-nav.php'; ?>
<div class="admin-layout">
    <?php include 'admin-sidebar.php'; ?>
    <main class="admin-main">
        <div class="admin-header">
            <div>
                <p class="admin-comment">// <?= count($blogs) ?> posts total</p>
                <h1>All Blog Posts</h1>
            </div>
            <a href="add-blog.php" class="btn-green">+ New Post</a>
        </div>
        <?php if ($msg): ?><div class="alert alert-success">✓ <?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <div class="table-wrap">
            <table class="admin-table">
                <thead><tr><th>Title</th><th>Category</th><th>Date</th><th>Featured</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach($blogs as $b): ?>
                <tr>
                    <td><span class="table-icon"><?= $b['image'] ?></span> <?= htmlspecialchars($b['title']) ?></td>
                    <td><span class="badge"><?= htmlspecialchars($b['category']) ?></span></td>
                    <td class="date-cell"><?= $b['date'] ?></td>
                    <td><?= $b['featured'] ? '<span style="color:var(--green)">★ Yes</span>' : '<span style="color:var(--muted)">—</span>' ?></td>
                    <td>
                        <a href="add-blog.php?edit=<?= $b['id'] ?>" class="action-btn">Edit</a>
                        <a href="delete-blog.php?id=<?= $b['id'] ?>&csrf=<?= csrf_token() ?>" class="action-btn danger" onclick="return confirm('Delete this post?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
</body>
</html>
