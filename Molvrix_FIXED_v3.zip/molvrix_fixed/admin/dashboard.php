<?php
require_once __DIR__ . '/admin-auth.php';
require_once __DIR__ . '/../api/logger.php';

$products   = json_decode(file_get_contents(__DIR__.'/../data/products.json'), true) ?: [];
$blogs      = json_decode(file_get_contents(__DIR__.'/../data/blogs.json'), true) ?: [];
$revenue    = array_sum(array_column($products, 'price'));
$logSummary = MolvrixLog::summary(7);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — MOLVRIX Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Space+Mono:wght@400;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
<?php include 'admin-styles.php'; ?>
</style>
</head>
<body>
<?php include 'admin-nav.php'; ?>
<div class="admin-layout">
    <?php include 'admin-sidebar.php'; ?>
    <main class="admin-main">
        <div class="admin-header">
            <div>
                <p class="admin-comment">// welcome back, admin</p>
                <h1>Dashboard</h1>
            </div>
            <div class="header-actions">
                <a href="add-product.php" class="btn-green">+ Add Product</a>
                <a href="add-blog.php" class="btn-outline">+ New Post</a>
            </div>
        </div>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M10 2L2 6v8l8 4 8-4V6L10 2z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M2 6l8 4 8-4M10 10v8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg></div>
                <div class="stat-num"><?= count($products) ?></div>
                <div class="stat-label">Total Products</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M14.5 2.5a2.12 2.12 0 0 1 3 3L6 17H3v-3L14.5 2.5z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg></div>
                <div class="stat-num"><?= count($blogs) ?></div>
                <div class="stat-label">Blog Posts</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M3 3h6l8 8-6 6-8-8V3z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><circle cx="7" cy="7" r="1.2" fill="currentColor"/></svg></div>
                <div class="stat-num">6</div>
                <div class="stat-label">Categories</div>
            </div>
            <div class="stat-card green">
                <div class="stat-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><circle cx="10" cy="10" r="7" stroke="#2ea043" stroke-width="1.4"/><circle cx="10" cy="10" r="3" fill="#2ea043" opacity="0.6"/></svg></div>
                <div class="stat-num">Live</div>
                <div class="stat-label">Site Status</div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="section-title">Quick Actions</div>
        <div class="quick-grid">
            <a href="add-product.php" class="quick-card">
                <span class="quick-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M10 2L2 6v8l8 4 8-4V6L10 2z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M2 6l8 4 8-4M10 10v8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg></span>
                <div>
                    <strong>Add New Product</strong>
                    <p>Upload file, set price, publish</p>
                </div>
                <span class="quick-arrow">→</span>
            </a>
            <a href="add-blog.php" class="quick-card">
                <span class="quick-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M14.5 2.5a2.12 2.12 0 0 1 3 3L6 17H3v-3L14.5 2.5z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg></span>
                <div>
                    <strong>Write Blog Post</strong>
                    <p>New article, SEO, publish</p>
                </div>
                <span class="quick-arrow">→</span>
            </a>
            <a href="products.php" class="quick-card">
                <span class="quick-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M14.5 2.5a2.12 2.12 0 0 1 3 3L6 17H3v-3L14.5 2.5z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg></span>
                <div>
                    <strong>Edit Products</strong>
                    <p>Update prices, descriptions</p>
                </div>
                <span class="quick-arrow">→</span>
            </a>
            <a href="blogs.php" class="quick-card">
                <span class="quick-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M4 2h8l5 5v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><polyline points="12,2 12,7 17,7" stroke="currentColor" stroke-width="1.4"/><line x1="7" y1="11" x2="13" y2="11" stroke="currentColor" stroke-width="1.2" opacity="0.7" stroke-linecap="round"/><line x1="7" y1="14" x2="11" y2="14" stroke="currentColor" stroke-width="1.2" opacity="0.5" stroke-linecap="round"/></svg></span>
                <div>
                    <strong>Manage Posts</strong>
                    <p>Edit, delete, schedule posts</p>
                </div>
                <span class="quick-arrow">→</span>
            </a>
            <a href="../index.html" target="_blank" class="quick-card">
                <span class="quick-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><circle cx="10" cy="10" r="8" stroke="currentColor" stroke-width="1.4"/><path d="M10 2c-2 3-3 5-3 8s1 5 3 8M10 2c2 3 3 5 3 8s-1 5-3 8M2 10h16" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" opacity="0.7"/></svg></span>
                <div>
                    <strong>View Live Site</strong>
                    <p>Opens in new tab</p>
                </div>
                <span class="quick-arrow">→</span>
            </a>
            <a href="logout.php" class="quick-card danger">
                <span class="quick-icon"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><rect x="4" y="9" width="12" height="9" rx="2" stroke="currentColor" stroke-width="1.4"/><path d="M7 9V6a3 3 0 0 1 6 0v3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><circle cx="10" cy="13.5" r="1.2" fill="currentColor"/></svg></span>
                <div>
                    <strong>Logout</strong>
                    <p>End admin session</p>
                </div>
                <span class="quick-arrow">→</span>
            </a>
        </div>

        <!-- Recent Products -->
        <!-- 7-day log summary -->
        <div class="section-title" style="margin-top:2.5rem">System Health <span style="font-family:'DM Mono',monospace;font-size:0.65rem;color:var(--muted);font-weight:400">// last 7 days</span></div>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0.75rem;margin-bottom:0.5rem;">
            <a href="logs.php?cat=payment" style="text-decoration:none;background:var(--black-3);border:1px solid var(--border);border-radius:8px;padding:1rem 1.2rem;display:block;transition:border-color 0.2s;" onmouseover="this.style.borderColor='rgba(46,160,67,0.4)'" onmouseout="this.style.borderColor='var(--border)'">
                <div style="font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;color:var(--green);"><?= $logSummary['payment'] ?></div>
                <div style="font-family:'Space Mono',monospace;font-size:0.58rem;text-transform:uppercase;letter-spacing:0.1em;color:var(--muted);margin-top:0.2rem;">Payments</div>
            </a>
            <a href="logs.php?cat=error" style="text-decoration:none;background:var(--black-3);border:1px solid <?= $logSummary['error']>0?'rgba(248,81,73,0.3)':'var(--border)' ?>;border-radius:8px;padding:1rem 1.2rem;display:block;transition:border-color 0.2s;" onmouseover="this.style.borderColor='rgba(248,81,73,0.5)'" onmouseout="this.style.borderColor='<?= $logSummary['error']>0?'rgba(248,81,73,0.3)':'var(--border)' ?>'">
                <div style="font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;color:<?= $logSummary['error']>0?'#f85149':'var(--muted)' ?>;"><?= $logSummary['error'] ?></div>
                <div style="font-family:'Space Mono',monospace;font-size:0.58rem;text-transform:uppercase;letter-spacing:0.1em;color:var(--muted);margin-top:0.2rem;">Errors</div>
            </a>
            <a href="logs.php?cat=security" style="text-decoration:none;background:var(--black-3);border:1px solid <?= $logSummary['security']>0?'rgba(227,179,65,0.3)':'var(--border)' ?>;border-radius:8px;padding:1rem 1.2rem;display:block;transition:border-color 0.2s;" onmouseover="this.style.borderColor='rgba(227,179,65,0.5)'" onmouseout="this.style.borderColor='<?= $logSummary['security']>0?'rgba(227,179,65,0.3)':'var(--border)' ?>'">
                <div style="font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;color:<?= $logSummary['security']>0?'#e3b341':'var(--muted)' ?>;"><?= $logSummary['security'] ?></div>
                <div style="font-family:'Space Mono',monospace;font-size:0.58rem;text-transform:uppercase;letter-spacing:0.1em;color:var(--muted);margin-top:0.2rem;">Security</div>
            </a>
            <a href="logs.php?cat=activity" style="text-decoration:none;background:var(--black-3);border:1px solid var(--border);border-radius:8px;padding:1rem 1.2rem;display:block;transition:border-color 0.2s;" onmouseover="this.style.borderColor='rgba(88,166,255,0.4)'" onmouseout="this.style.borderColor='var(--border)'">
                <div style="font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;color:#58a6ff;"><?= $logSummary['activity'] ?></div>
                <div style="font-family:'Space Mono',monospace;font-size:0.58rem;text-transform:uppercase;letter-spacing:0.1em;color:var(--muted);margin-top:0.2rem;">Activity</div>
            </a>
        </div>
        <?php if ($logSummary['error'] > 0 || $logSummary['security'] > 5): ?>
        <div style="background:rgba(248,81,73,0.06);border:1px solid rgba(248,81,73,0.2);border-radius:6px;padding:0.75rem 1rem;margin-bottom:1.5rem;font-family:'Space Mono',monospace;font-size:0.68rem;color:#f85149;">
            ⚠ <?php
                $alerts = [];
                if ($logSummary['error'] > 0) $alerts[] = $logSummary['error'] . ' error' . ($logSummary['error']>1?'s':'') . ' in last 7 days';
                if ($logSummary['security'] > 5) $alerts[] = $logSummary['security'] . ' security events — check for attacks';
                echo implode(' · ', $alerts);
            ?> — <a href="logs.php" style="color:#f85149;">View Logs →</a>
        </div>
        <?php endif; ?>

        <div class="section-title" style="margin-top:2.5rem">Recent Products</div>
        <div class="table-wrap">
            <table class="admin-table">
                <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach(array_slice($products, 0, 5) as $p): ?>
                <tr>
                    <td><span class="table-icon"><?= $p['icon'] ?></span> <?= htmlspecialchars($p['name']) ?></td>
                    <td><span class="badge"><?= htmlspecialchars($p['category']) ?></span></td>
                    <td class="price-cell">$<?= $p['price'] ?><?= $p['originalPrice'] ? ' <span class="orig">$'.$p['originalPrice'].'</span>' : '' ?></td>
                    <td>
                        <a href="add-product.php?edit=<?= $p['id'] ?>" class="action-btn">Edit</a>
                        <a href="delete-product.php?id=<?= $p['id'] ?>" class="action-btn danger" onclick="return confirm('Delete this product?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <a href="products.php" class="view-all">View all <?= count($products) ?> products →</a>

        <!-- Recent Blogs -->
        <div class="section-title" style="margin-top:2.5rem">Recent Blog Posts</div>
        <div class="table-wrap">
            <table class="admin-table">
                <thead><tr><th>Title</th><th>Category</th><th>Date</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach(array_slice($blogs, 0, 5) as $b): ?>
                <tr>
                    <td><span class="table-icon"><?= $b['image'] ?></span> <?= htmlspecialchars($b['title']) ?></td>
                    <td><span class="badge"><?= htmlspecialchars($b['category']) ?></span></td>
                    <td class="date-cell"><?= $b['date'] ?></td>
                    <td>
                        <a href="add-blog.php?edit=<?= $b['id'] ?>" class="action-btn">Edit</a>
                        <a href="delete-blog.php?id=<?= $b['id'] ?>" class="action-btn danger" onclick="return confirm('Delete this post?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <a href="blogs.php" class="view-all">View all <?= count($blogs) ?> posts →</a>
    </main>
</div>
</body>
</html>
