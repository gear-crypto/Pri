<?php
// delete-product.php — CSRF protected
require_once __DIR__ . '/admin-auth.php';
require_once 'csrf.php';
csrf_verify();

$id   = $_GET['id'] ?? '';
$file = __DIR__.'/../data/products.json';
$products = json_decode(file_get_contents($file), true) ?: [];
$products = array_values(array_filter($products, fn($p) => $p['id'] !== $id));
file_put_contents($file, json_encode($products, JSON_PRETTY_PRINT));
header('Location: products.php?msg=Product+deleted');
