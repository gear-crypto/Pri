<?php
/**
 * MOLVRIX — Admin Logout
 * Destroys the PHP session completely and redirects to login.
 */
session_start();

// Wipe all session data
$_SESSION = [];

// Destroy the session cookie
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), '', time() - 42000,
        $params['path'], $params['domain'],
        $params['secure'], $params['httponly']
    );
}

session_destroy();
header('Location: login.php?msg=logged_out');
exit;
