<?php
require_once __DIR__ . '/admin-auth.php';

$file     = __DIR__.'/../data/products.json';
$products = json_decode(file_get_contents($file), true) ?: [];
$editId   = $_GET['edit'] ?? null;
$editing  = null;
$msg      = '';
$err      = '';

if ($editId) {
    foreach ($products as $p) { if ($p['id'] === $editId) { $editing = $p; break; } }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id       = $_POST['id']            ?? ('prod-'.uniqid());
    $name     = trim($_POST['name']     ?? '');
    $category = trim($_POST['category'] ?? '');
    $price    = floatval($_POST['price'] ?? 0);
    $origPrice= $_POST['originalPrice'] ? floatval($_POST['originalPrice']) : null;
    $badge    = trim($_POST['badge']    ?? '');
    $icon     = trim($_POST['icon']     ?? 'product');
    $download_url = trim($_POST['download_url'] ?? '');
    $desc     = trim($_POST['description'] ?? '');
    $includes = array_filter(array_map('trim', explode("\n", $_POST['includes'] ?? '')));
    $thumbBg  = trim($_POST['thumbBg']  ?? 'linear-gradient(135deg, #0d1117, #0a1628)');
    $thumbCode= trim($_POST['thumbCode'] ?? '');

    if (!$name || !$category || !$price) {
        $err = 'Name, category, and price are required.';
    } else {
        $product = compact('id','name','category','icon','price','origPrice','badge','download_url','desc','thumbBg','thumbCode');
        $product['originalPrice'] = $origPrice;
        $product['description']   = $desc;
        $product['includes']      = array_values($includes);
        unset($product['desc'], $product['origPrice']);

        // Update or insert
        $found = false;
        foreach ($products as &$p) {
            if ($p['id'] === $id) { $p = $product; $found = true; break; }
        }
        if (!$found) { array_unshift($products, $product); }
        file_put_contents($file, json_encode($products, JSON_PRETTY_PRINT));
        $msg = $found ? 'Product updated!' : 'Product added!';
        if (!$found) { header('Location: products.php?msg='.urlencode($msg)); exit; }
        $editing = $product;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $editing ? 'Edit Product' : 'Add Product' ?> — MOLVRIX Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Space+Mono:wght@400;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style><?php include 'admin-styles.php'; ?></style>
</head>
<body>
<?php include 'admin-nav.php'; ?>
<div class="admin-layout">
    <?php include 'admin-sidebar.php'; ?>
    <main class="admin-main">
        <div class="admin-header">
            <div>
                <p class="admin-comment">// <?= $editing ? 'editing: '.$editing['name'] : 'new product' ?></p>
                <h1><?= $editing ? 'Edit Product' : 'Add Product' ?></h1>
            </div>
            <a href="products.php" class="btn-outline">← Back to Products</a>
        </div>

        <?php if ($msg): ?><div class="alert alert-success">✓ <?= $msg ?></div><?php endif; ?>
        <?php if ($err): ?><div class="alert alert-error">✗ <?= $err ?></div><?php endif; ?>

        <form method="POST">
            <?php if ($editing): ?><input type="hidden" name="id" value="<?= $editing['id'] ?>"><?php endif; ?>

            <div class="form-card">
                <div class="form-card-title">Basic Info</div>
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Product Name *</label>
                        <input type="text" name="name" class="form-input" placeholder="e.g. Zapier Master Kit" value="<?= htmlspecialchars($editing['name'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Category *</label>
                        <select name="category" class="form-select" required>
                            <option value="">Select category</option>
                            <?php foreach(['Automation','Operations','AI & Copy','Productivity','Learning','Specialist'] as $cat): ?>
                            <option value="<?= $cat ?>" <?= ($editing['category']??'')===$cat?'selected':'' ?>><?= $cat ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Price ($) *</label>
                        <input type="number" name="price" class="form-input" placeholder="29" value="<?= $editing['price'] ?? '' ?>" min="1" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Original Price (if on sale)</label>
                        <input type="number" name="originalPrice" class="form-input" placeholder="49" value="<?= $editing['originalPrice'] ?? '' ?>" min="1" step="0.01">
                        <p class="form-hint">Leave blank if not on sale</p>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Icon Code</label>
                        <input type="text" name="icon" class="form-input" placeholder="automation, sop, ai, product ..." value="<?= $editing['icon'] ?? 'product' ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Badge</label>
                        <select name="badge" class="form-select">
                            <option value="">None</option>
                            <option value="hot" <?= ($editing['badge']??'')==='hot'?'selected':'' ?>><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M10 2c0 3-3 4-3 7a3 3 0 0 0 6 0c0-1-.5-2-.5-2s-1 1-1.5 1c0-2 2-4 2-6a5 5 0 0 0-3 0z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg> Hot</option>
                            <option value="new" <?= ($editing['badge']??'')==='new'?'selected':'' ?>>New</option>
                            <option value="sale" <?= ($editing['badge']??'')==='sale'?'selected':'' ?>>Sale</option>
                        </select>
                    </div>
                    <div class="form-group full">
                        <label class="form-label">Description *</label>
                        <textarea name="description" class="form-textarea" style="min-height:100px" placeholder="Short product description..." required><?= htmlspecialchars($editing['description'] ?? '') ?></textarea>
                    </div>
                    <div class="form-group full">
                        <label class="form-label">What's Included (one item per line)</label>
                        <textarea name="includes" class="form-textarea" style="min-height:120px" placeholder="50+ ready-to-use Zaps&#10;Lead capture automations&#10;Client onboarding flows"><?= htmlspecialchars(implode("\n", $editing['includes'] ?? [])) ?></textarea>
                    </div>
                </div>
            </div>

            <div class="form-card">
                <div class="form-card-title">Payment & Display</div>
                <div class="form-grid">
                    <div class="form-group full">
                        <label class="form-label">Product Download URL</label>
                        <input type="url" name="download_url" class="form-input" placeholder="https://... (Supabase Storage URL or uploaded file URL)" value="<?= htmlspecialchars($editing['download_url'] ?? '') ?>">
                        <p class="form-hint">The direct download link customers receive after purchase. Use Supabase Storage or upload via Admin → Media Library.</p>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Thumbnail Background CSS</label>
                        <input type="text" name="thumbBg" class="form-input" placeholder="linear-gradient(135deg, #0d1117, #0a1628)" value="<?= htmlspecialchars($editing['thumbBg'] ?? 'linear-gradient(135deg, #0d1117, #0a1628)') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Thumbnail Code Line</label>
                        <input type="text" name="thumbCode" class="form-input" placeholder="./deploy --auto" value="<?= htmlspecialchars($editing['thumbCode'] ?? '') ?>">
                    </div>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-green">$ <?= $editing ? 'Update Product' : 'Publish Product' ?> →</button>
                <a href="products.php" class="btn-outline">Cancel</a>
            </div>
        </form>
    </main>
</div>
</body>
</html>
