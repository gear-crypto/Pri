<?php
require_once __DIR__ . '/admin-auth.php';

$file  = __DIR__.'/../data/blogs.json';
$blogs = json_decode(file_get_contents($file), true) ?: [];
$editId  = $_GET['edit'] ?? null;
$editing = null;
$msg = ''; $err = '';

if ($editId) {
    foreach ($blogs as $b) { if ($b['id'] === $editId) { $editing = $b; break; } }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id       = $_POST['id']       ?? ('blog-'.uniqid());
    $title    = trim($_POST['title']    ?? '');
    $category = trim($_POST['category'] ?? '');
    $excerpt  = trim($_POST['excerpt']  ?? '');
    $content  = $_POST['content']  ?? '';
    $image    = trim($_POST['image']    ?? 'docs');
    $author   = trim($_POST['author']   ?? 'MOLVRIX Team');
    $readTime = trim($_POST['readTime'] ?? '5 min read');
    $featured = isset($_POST['featured']);
    $date     = $_POST['date'] ?? date('Y-m-d');
    $slug     = strtolower(preg_replace('/[^a-z0-9]+/i', '-', trim($_POST['slug'] ?? $title)));

    if (!$title || !$category || !$content) { $err = 'Title, category, and content are required.'; }
    else {
        $post = compact('id','title','slug','category','date','author','excerpt','content','image','readTime','featured');
        $found = false;
        foreach ($blogs as &$b) { if ($b['id'] === $id) { $b = $post; $found = true; break; } }
        if (!$found) { array_unshift($blogs, $post); }
        file_put_contents($file, json_encode($blogs, JSON_PRETTY_PRINT));
        $msg = $found ? 'Post updated!' : 'Post published!';
        if (!$found) { header('Location: blogs.php?msg='.urlencode($msg)); exit; }
        $editing = $post;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $editing ? 'Edit Post' : 'New Post' ?> — MOLVRIX Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Space+Mono:wght@400;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style><?php include 'admin-styles.php'; ?></style>
</head>
<body>
<?php include 'admin-nav.php'; ?>
<div class="admin-layout">
    <?php include 'admin-sidebar.php'; ?>
    <main class="admin-main">
        <div class="admin-header">
            <div>
                <p class="admin-comment">// <?= $editing ? 'editing post' : 'new blog post' ?></p>
                <h1><?= $editing ? 'Edit Post' : 'New Blog Post' ?></h1>
            </div>
            <a href="blogs.php" class="btn-outline">← Back</a>
        </div>

        <?php if ($msg): ?><div class="alert alert-success">✓ <?= $msg ?></div><?php endif; ?>
        <?php if ($err): ?><div class="alert alert-error">✗ <?= $err ?></div><?php endif; ?>

        <form method="POST">
            <?php if ($editing): ?><input type="hidden" name="id" value="<?= $editing['id'] ?>"><?php endif; ?>

            <div class="form-card">
                <div class="form-card-title">Post Details</div>
                <div class="form-grid">
                    <div class="form-group full">
                        <label class="form-label">Post Title *</label>
                        <input type="text" name="title" class="form-input" placeholder="e.g. How to Save 20 Hours Using Zapier" value="<?= htmlspecialchars($editing['title'] ?? '') ?>" required>
                    </div>
                    <div class="form-group full">
                        <label class="form-label">URL Slug</label>
                        <input type="text" name="slug" class="form-input" placeholder="how-to-save-20-hours-zapier" value="<?= htmlspecialchars($editing['slug'] ?? '') ?>">
                        <p class="form-hint">Leave blank to auto-generate from title</p>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Category *</label>
                        <select name="category" class="form-select" required>
                            <option value="">Select category</option>
                            <?php foreach(['Automation','Operations','AI & Copy','Productivity','Learning','Specialist','General'] as $cat): ?>
                            <option value="<?= $cat ?>" <?= ($editing['category']??'')===$cat?'selected':'' ?>><?= $cat ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Publish Date</label>
                        <input type="date" name="date" class="form-input" value="<?= $editing['date'] ?? date('Y-m-d') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Author</label>
                        <input type="text" name="author" class="form-input" placeholder="MOLVRIX Team" value="<?= htmlspecialchars($editing['author'] ?? 'MOLVRIX Team') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Read Time</label>
                        <input type="text" name="readTime" class="form-input" placeholder="5 min read" value="<?= htmlspecialchars($editing['readTime'] ?? '5 min read') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Icon Code</label>
                        <input type="text" name="image" class="form-input" placeholder="docs, automation, ai ..." value="<?= htmlspecialchars($editing['image'] ?? 'docs') ?>">
                    </div>
                    <div class="form-group" style="display:flex;align-items:center;gap:0.8rem;padding-top:1.5rem">
                        <input type="checkbox" name="featured" id="featured" <?= ($editing['featured']??false)?'checked':'' ?> style="width:18px;height:18px;accent-color:var(--green)">
                        <label for="featured" class="form-label" style="margin:0;cursor:pointer">Mark as Featured Post</label>
                    </div>
                    <div class="form-group full">
                        <label class="form-label">Excerpt / Summary</label>
                        <textarea name="excerpt" class="form-textarea" style="min-height:80px" placeholder="Short summary shown on blog listing page..."><?= htmlspecialchars($editing['excerpt'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

            <div class="form-card">
                <div class="form-card-title">Post Content</div>
                <!-- Simple toolbar -->
                <div class="editor-toolbar">
                    <button type="button" class="editor-btn" onclick="fmt('bold')"><b>B</b></button>
                    <button type="button" class="editor-btn" onclick="fmt('italic')"><i>I</i></button>
                    <button type="button" class="editor-btn" onclick="fmt('h2')">H2</button>
                    <button type="button" class="editor-btn" onclick="fmt('h3')">H3</button>
                    <button type="button" class="editor-btn" onclick="fmt('p')">¶</button>
                    <button type="button" class="editor-btn" onclick="fmt('ul')">• List</button>
                    <button type="button" class="editor-btn" onclick="fmt('link')"><svg viewBox="0 0 20 20" fill="none" width="14" height="14"><path d="M8 12a4 4 0 0 0 5.7.3l2-2a4 4 0 0 0-5.6-5.7L9 5.7M12 8a4 4 0 0 0-5.7-.3l-2 2a4 4 0 0 0 5.6 5.7l1.1-1.1" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg> Link</button>
                    <button type="button" class="editor-btn" onclick="fmt('code')">{'<>'}</button>
                </div>
                <div id="contentEditor" class="form-textarea" contenteditable="true" style="padding:1rem;outline:none;line-height:1.8;border:1px solid var(--border);border-top:none;border-radius:0 0 4px 4px;min-height:300px"><?= $editing['content'] ?? '' ?></div>
                <input type="hidden" name="content" id="contentInput">
                <p class="form-hint" style="margin-top:0.5rem">Write HTML or plain text. Use the toolbar for formatting.</p>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-green" onclick="document.getElementById('contentInput').value=document.getElementById('contentEditor').innerHTML">
                    $ <?= $editing ? 'Update Post' : 'Publish Post' ?> →
                </button>
                <a href="blogs.php" class="btn-outline">Cancel</a>
            </div>
        </form>
    </main>
</div>
<script>
function fmt(type) {
    const editor = document.getElementById('contentEditor');
    editor.focus();
    const sel = window.getSelection();
    const text = sel.toString() || 'Text here';
    switch(type) {
        case 'bold':   document.execCommand('bold'); break;
        case 'italic': document.execCommand('italic'); break;
        case 'h2':     document.execCommand('insertHTML', false, `<h2>${text}</h2><br>`); break;
        case 'h3':     document.execCommand('insertHTML', false, `<h3>${text}</h3><br>`); break;
        case 'p':      document.execCommand('insertHTML', false, `<p>${text}</p>`); break;
        case 'ul':     document.execCommand('insertHTML', false, `<ul><li>${text}</li></ul>`); break;
        case 'link':
            const url = prompt('URL:', 'https://');
            if (url) document.execCommand('insertHTML', false, `<a href="${url}" target="_blank">${text}</a>`);
            break;
        case 'code':   document.execCommand('insertHTML', false, `<code>${text}</code>`); break;
    }
}
// Sync on submit
document.querySelector('form').addEventListener('submit', () => {
    document.getElementById('contentInput').value = document.getElementById('contentEditor').innerHTML;
});
</script>
</body>
</html>
