<?php
/**
 * MOLVRIX — CSRF Token Helper
 * Include in admin pages that have delete/write actions.
 *
 * Usage in forms/links:
 *   <a href="delete-product.php?id=...&csrf=<?= csrf_token() ?>">Delete</a>
 *
 * Usage in delete handlers:
 *   require_once 'csrf.php';
 *   csrf_verify();
 */

if (session_status() === PHP_SESSION_NONE) session_start();

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_verify(): void {
    $token = $_GET['csrf'] ?? $_POST['csrf'] ?? '';
    $stored = $_SESSION['csrf_token'] ?? '';
    if (!$stored || !hash_equals($stored, $token)) {
        http_response_code(403);
        // Redirect back with error rather than a blank page
        header('Location: dashboard.php?err=csrf');
        exit;
    }
}
