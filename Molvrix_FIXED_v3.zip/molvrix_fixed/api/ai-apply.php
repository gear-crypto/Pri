<?php
/**
 * MOLVRIX — AI Code Apply Engine
 * POST /api/ai-apply.php
 * Reads site files and optionally writes AI-generated patches
 *
 * FIX 1: $body is now parsed BEFORE the auth check (was parsed after — a critical bug).
 * FIX 2: Bootstrap bypass removed. save-config now requires either:
 *   (a) A valid stored token (normal operation), OR
 *   (b) A MOLVRIX_SETUP_SECRET env var match (one-time initial setup).
 *       Set this on your server: export MOLVRIX_SETUP_SECRET="your-secret"
 *       Once admin_token is saved, this env var path is never hit again.
 */
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// ── Parse body FIRST ──
$body   = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $body['action'] ?? '';
$root   = realpath(__DIR__ . '/..');

// ── Load config ──
$cfgFile  = __DIR__ . '/../data/ai-config.json';
$cfg      = file_exists($cfgFile) ? json_decode(file_get_contents($cfgFile), true) : [];
$reqToken = $_SERVER['HTTP_X_ADMIN_TOKEN'] ?? '';
$stored   = $cfg['admin_token'] ?? '';

// ── Auth check ──
// Normal path: token must match stored value.
// Initial setup: no stored token + request matches MOLVRIX_SETUP_SECRET env var.
$setupSecret    = getenv('MOLVRIX_SETUP_SECRET') ?: '';
$isInitialSetup = ($action === 'save-config')
    && !$stored
    && $setupSecret
    && hash_equals($setupSecret, $reqToken);

$authorized = ($stored && hash_equals($stored, $reqToken)) || $isInitialSetup;

if (!$authorized) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// ── Allowed file paths (whitelist) ──
function isAllowed(string $path, string $root): bool {
    $real = realpath($path);
    if (!$real) return false;
    if (strpos($real, $root) !== 0) return false;              // path traversal check
    $rel = ltrim(str_replace($root, '', $real), '/\\');
    // Protect sensitive files
    $blocked = ['data/ai-config.json', 'api/ai-apply.php', '.env', '.htaccess'];
    foreach ($blocked as $b) { if (strpos($rel, $b) !== false) return false; }
    // Only allow specific extensions
    $ext = strtolower(pathinfo($real, PATHINFO_EXTENSION));
    return in_array($ext, ['html','css','js','php','json','md','sql','txt']);
}

// ── READ file ──
if ($action === 'read') {
    $file = $root . '/' . ltrim($body['file'] ?? '', '/');
    if (!isAllowed($file, $root)) { echo json_encode(['error'=>'File not allowed']); exit; }
    if (!file_exists($file)) { echo json_encode(['error'=>'File not found']); exit; }
    echo json_encode(['success'=>true,'content'=>file_get_contents($file),'file'=>$body['file']]);
    exit;
}

// ── LIST files ──
if ($action === 'list') {
    $files = [];
    $media = [];
    $iter  = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS));
    foreach ($iter as $f) {
        if ($f->isFile()) {
            $rel = str_replace($root . DIRECTORY_SEPARATOR, '', $f->getPathname());
            $rel = str_replace('\\', '/', $rel);
            if (strpos($rel, 'admin/') === 0 || strpos($rel, 'data/') === 0) continue;
            if (strpos($rel, 'uploads/') === 0) {
                $media[] = ['path' => $rel, 'type' => 'media', 'size' => $f->getSize()];
                continue;
            }
            $ext = strtolower($f->getExtension());
            if (!in_array($ext, ['html','css','js','php'])) continue;
            $files[] = ['path' => $rel, 'type' => 'source'];
        }
    }
    usort($files, function($a,$b){ return strcmp($a['path'],$b['path']); });
    usort($media, function($a,$b){ return strcmp($a['path'],$b['path']); });
    echo json_encode(['success'=>true, 'files'=> array_merge($files, $media)]);
    exit;
}

// ── WRITE (apply patch) ──
if ($action === 'write') {
    $file    = $root . '/' . ltrim($body['file'] ?? '', '/');
    $content = $body['content'] ?? '';
    if (!isAllowed($file, $root)) { echo json_encode(['error'=>'File not allowed']); exit; }
    if (empty($content)) { echo json_encode(['error'=>'Empty content']); exit; }

    // Backup original
    $backupDir = $root . '/data/ai-backups';
    if (!is_dir($backupDir)) mkdir($backupDir, 0755, true);
    $backupFile = $backupDir . '/' . str_replace('/', '_', $body['file']) . '.' . time() . '.bak';
    if (file_exists($file)) file_put_contents($backupFile, file_get_contents($file));

    // Write new content
    $ok = file_put_contents($file, $content);
    if ($ok === false) { echo json_encode(['error'=>'Write failed — check file permissions']); exit; }
    echo json_encode(['success'=>true,'message'=>'File updated successfully','backup'=>basename($backupFile),'bytes'=>$ok]);
    exit;
}

// ── RESTORE from backup ──
if ($action === 'restore') {
    $backup = $root . '/data/ai-backups/' . basename($body['backup'] ?? '');
    $target = $root . '/' . ltrim($body['file'] ?? '', '/');
    if (!file_exists($backup)) { echo json_encode(['error'=>'Backup not found']); exit; }
    if (!isAllowed($target, $root)) { echo json_encode(['error'=>'File not allowed']); exit; }
    copy($backup, $target);
    echo json_encode(['success'=>true,'message'=>'Restored from backup']);
    exit;
}

// ── HEALTH SCAN ──
if ($action === 'scan') {
    $issues = [];
    $scanFiles = ['index.html','products.html','cart.html','login.html','admin/panel.html','js/config.js','api/razorpay-order.php','api/razorpay-verify.php'];
    foreach ($scanFiles as $rel) {
        $path = $root . '/' . $rel;
        if (!file_exists($path)) { $issues[] = ['file'=>$rel,'type'=>'missing','msg'=>'File does not exist']; continue; }
        $c = file_get_contents($path);
        if (strpos($c, 'YOUR_PROJECT') !== false)  $issues[] = ['file'=>$rel,'type'=>'config','msg'=>'Supabase URL not configured (YOUR_PROJECT placeholder)'];
        if (strpos($c, 'YOUR_KEY_ID') !== false)   $issues[] = ['file'=>$rel,'type'=>'config','msg'=>'Razorpay key not configured (YOUR_KEY_ID placeholder)'];
        if (strpos($c, 'gumroad.com/l/') !== false) $issues[] = ['file'=>$rel,'type'=>'warning','msg'=>'Gumroad link found — remove it, MOLVRIX uses Razorpay'];
        if ($rel === 'admin/panel.html' && strpos($c,'YOUR_PROJECT') !== false) continue; // allowed in panel
    }
    echo json_encode(['success'=>true,'issues'=>$issues,'scanned'=>count($scanFiles)]);
    exit;
}

// ── SAVE AI CONFIG ──
if ($action === 'save-config') {
    $config     = $body['config'] ?? [];
    $safeConfig = [
        'claude_key'   => preg_replace('/[^a-zA-Z0-9\-_]/', '', $config['claude_key']   ?? ''),
        'gemini_key'   => preg_replace('/[^a-zA-Z0-9\-_]/', '', $config['gemini_key']   ?? ''),
        'openai_key'   => preg_replace('/[^a-zA-Z0-9\-_.%+]/', '', $config['openai_key'] ?? ''),
        'admin_token'  => preg_replace('/[^a-zA-Z0-9\-_]/', '', $config['admin_token']  ?? ''),
        'claude_model' => $config['claude_model'] ?? 'claude-sonnet-4-20250514',
        'gemini_model' => $config['gemini_model'] ?? 'gemini-2.0-flash',
        'openai_model' => $config['openai_model'] ?? 'gpt-4o',
    ];
    // Ensure data dir exists
    $dataDir = $root . '/data';
    if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
    $ok = file_put_contents($cfgFile, json_encode($safeConfig, JSON_PRETTY_PRINT));
    if ($ok === false) { echo json_encode(['error' => 'Could not write config. Check server permissions on /data/']); exit; }
    echo json_encode(['success' => true, 'message' => 'Config saved']);
    exit;
}

echo json_encode(['error'=>'Unknown action']);
