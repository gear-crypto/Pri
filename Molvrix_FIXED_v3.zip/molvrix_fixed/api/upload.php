<?php
/**
 * MOLVRIX — Universal Upload Handler
 * POST /api/upload.php
 * Handles: product thumbnails, product download files, blog covers, testimonial avatars, site assets
 */
header('Content-Type: application/json');

$cfgFile  = __DIR__ . '/../data/ai-config.json';
$cfg      = file_exists($cfgFile) ? json_decode(file_get_contents($cfgFile), true) : [];
$reqToken = $_SERVER['HTTP_X_ADMIN_TOKEN'] ?? ($_POST['_token'] ?? '');
$stored   = $cfg['admin_token'] ?? '';
if (!$stored || $reqToken !== $stored) { http_response_code(403); echo json_encode(['error'=>'Unauthorized']); exit; }

$type = $_POST['type'] ?? 'thumbnail'; // thumbnail | download | blog_cover | avatar | asset
$root = realpath(__DIR__ . '/..');

// Type config: [allowed_mime, max_bytes, subdir, is_public]
$typeConfig = [
    'thumbnail'   => [['image/png','image/jpeg','image/webp','image/gif'], 3*1024*1024, 'uploads/thumbnails', true],
    'download'    => [['application/zip','application/pdf','application/octet-stream','application/x-zip-compressed'], 100*1024*1024, 'uploads/downloads', false],
    'blog_cover'  => [['image/png','image/jpeg','image/webp'], 5*1024*1024, 'uploads/blog-covers', true],
    'avatar'      => [['image/png','image/jpeg','image/webp'], 2*1024*1024, 'uploads/avatars', true],
    'asset'       => [['image/png','image/jpeg','image/webp','image/svg+xml','image/x-icon'], 2*1024*1024, 'uploads/assets', true],
];

if (!isset($typeConfig[$type])) { echo json_encode(['error'=>'Unknown upload type']); exit; }
[$allowedMimes, $maxBytes, $subdir, $isPublic] = $typeConfig[$type];

if (empty($_FILES['file'])) { echo json_encode(['error'=>'No file uploaded']); exit; }
$file = $_FILES['file'];

// Validate
if ($file['error'] !== UPLOAD_ERR_OK) { echo json_encode(['error'=>'Upload error code: '.$file['error']]); exit; }
if ($file['size'] > $maxBytes) { echo json_encode(['error'=>'File too large. Max: '.($maxBytes/1024/1024).'MB']); exit; }

$finfo    = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);
if (!in_array($mimeType, $allowedMimes)) { echo json_encode(['error'=>'File type not allowed: '.$mimeType]); exit; }

// Generate safe filename
$ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$safeName = preg_replace('/[^a-z0-9_-]/', '', strtolower(pathinfo($file['name'], PATHINFO_FILENAME)));
$safeName = substr($safeName, 0, 40);
$filename = $safeName . '_' . time() . '.' . $ext;

$uploadDir = $root . '/' . $subdir;
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

// Security: add .htaccess to prevent executing PHP in uploads
$htFile = $uploadDir . '/.htaccess';
if (!file_exists($htFile)) file_put_contents($htFile, "php_flag engine off\nAddType text/plain .php .phtml .php3");

$destPath = $uploadDir . '/' . $filename;
if (!move_uploaded_file($file['tmp_name'], $destPath)) { echo json_encode(['error'=>'Move failed']); exit; }

$publicUrl = '/' . $subdir . '/' . $filename;

echo json_encode([
    'success'   => true,
    'url'       => $publicUrl,
    'filename'  => $filename,
    'size'      => $file['size'],
    'mime'      => $mimeType,
    'is_public' => $isPublic,
    'type'      => $type,
]);
