<?php
/**
 * MOLVRIX — Razorpay Order Creator
 * POST /api/razorpay-order.php
 * Body: { items:[{id,name,price}], coupon?:string, email:string, name:string }
 */
// ── CORS: only allow requests from the site's own origin ──
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = [
    'http://localhost',
    'http://127.0.0.1',
    'https://molvrix.com',
];
$corsOrigin = in_array($origin, $allowed) ? $origin : ($allowed[2] ?? '*');
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . $corsOrigin);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST')    { http_response_code(405); echo json_encode(['error'=>'Method not allowed']); exit; }

// ══════════════════════════════════════════════════════
// Secrets loaded from environment / .env file (not hard-coded)
// See api/env.php for setup instructions.
// ══════════════════════════════════════════════════════
require_once __DIR__ . '/env.php';
define('RAZORPAY_KEY_ID',      molvrix_env('RAZORPAY_KEY_ID',      'rzp_test_YOUR_KEY_ID'));
define('RAZORPAY_KEY_SECRET',  molvrix_env('RAZORPAY_KEY_SECRET',  'YOUR_RAZORPAY_SECRET'));
define('CURRENCY',             'INR');
define('SUPABASE_URL',         molvrix_env('SUPABASE_URL',         'https://mrajnjxbudjyrdfmmape.supabase.co'));
define('SUPABASE_SERVICE_KEY', molvrix_env('SUPABASE_SERVICE_KEY', ''));
// ── Supabase config (for coupon validation) ──
// (SUPABASE_URL and SUPABASE_SERVICE_KEY now defined above via env.php)

// ── Rate limiting: max 15 order attempts per IP per hour ──
$ip      = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rlDir   = sys_get_temp_dir() . '/molvrix_order_rl';
if (!is_dir($rlDir)) @mkdir($rlDir, 0700, true);
$rlFile  = $rlDir . '/' . md5($ip) . '.json';
$window  = 3600; $maxHits = 15; $now = time();
$rlHits  = file_exists($rlFile) ? (json_decode(file_get_contents($rlFile), true) ?: []) : [];
$rlHits  = array_filter($rlHits, fn($t) => $t > $now - $window);
if (count($rlHits) >= $maxHits) {
    http_response_code(429);
    echo json_encode(['error' => 'Too many requests. Please try again later.']);
    exit;
}
$rlHits[] = $now;
file_put_contents($rlFile, json_encode(array_values($rlHits)), LOCK_EX);

// ── Server-side price catalog ──
// These are the AUTHORITATIVE prices. Client-submitted prices are IGNORED.
// Update this when you change product prices.
$catalogFile = __DIR__ . '/../data/products.json';
$catalogRaw  = file_exists($catalogFile) ? json_decode(file_get_contents($catalogFile), true) : [];
$catalog     = [];
foreach ($catalogRaw as $p) {
    if (!empty($p['id'])) $catalog[$p['id']] = floatval($p['price']);
}
// Bundle prices (not in products.json)
$catalog['bundle-starter'] = 6999;
$catalog['bundle-agency']  = 14999;
$catalog['bundle-creator'] = 3999;

// ── Parse body ──
$body  = json_decode(file_get_contents('php://input'), true);
$items = $body['items']  ?? [];
$email = htmlspecialchars(trim($body['email'] ?? ''));
$name  = htmlspecialchars(trim($body['name']  ?? 'Customer'));
$coupon= strtoupper(trim($body['coupon'] ?? ''));

if (empty($items) || !$email) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields (items, email)']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email address']);
    exit;
}
if (count($items) > 20) {
    http_response_code(400);
    echo json_encode(['error' => 'Too many items in cart']);
    exit;
}

// ── Validate items against server-side catalog & calculate subtotal ──
// Client-submitted prices are NEVER trusted. We look up the real price.
$subtotal      = 0;
$validatedItems = [];
foreach ($items as $item) {
    $id = trim($item['id'] ?? '');
    if (!$id || !isset($catalog[$id])) {
        http_response_code(400);
        echo json_encode(['error' => 'Unknown product: ' . htmlspecialchars($id)]);
        exit;
    }
    $realPrice = $catalog[$id];
    $subtotal += $realPrice;
    $validatedItems[] = [
        'id'    => $id,
        'name'  => htmlspecialchars(trim($item['name'] ?? $id)),
        'price' => $realPrice, // always use server price
    ];
}
// Replace client items with validated items from here on
$items = $validatedItems;

// ── Validate coupon via Supabase ──
$discount = 0;
$couponMeta = null;
if ($coupon) {
    $ch = curl_init(SUPABASE_URL . '/rest/v1/coupons?code=eq.' . urlencode($coupon) . '&active=eq.true&select=*');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'apikey: ' . SUPABASE_SERVICE_KEY,
            'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
        ],
    ]);
    $resp = curl_exec($ch);
    curl_close($ch);
    $coupons = json_decode($resp, true) ?: [];

    if (!empty($coupons)) {
        $c = $coupons[0];
        // Check expiry
        $expired = $c['expires_at'] && strtotime($c['expires_at']) < time();
        // Check max uses
        $maxed   = $c['max_uses'] && $c['used_count'] >= $c['max_uses'];
        // Check min order
        $belowMin= $subtotal < floatval($c['min_order']);

        if (!$expired && !$maxed && !$belowMin) {
            $couponMeta = $c;
            if ($c['type'] === 'percent') {
                $discount = round($subtotal * floatval($c['value']) / 100, 2);
            } else {
                $discount = min(floatval($c['value']), $subtotal);
            }
        }
    }
}

$total = max(0, $subtotal - $discount);

// Razorpay needs amount in smallest unit (paise for INR)
$amountPaise = intval(round($total * 100));
if ($amountPaise < 100) { // min ₹1
    http_response_code(400);
    echo json_encode(['error' => 'Order amount too small']);
    exit;
}

// ── Create Razorpay order ──
$orderData = [
    'amount'          => $amountPaise,
    'currency'        => CURRENCY,
    'receipt'         => 'mlvx_' . time() . '_' . substr(md5($email), 0, 6),
    'notes'           => [
        'customer_name'  => $name,
        'customer_email' => $email,
        'items_count'    => count($items),
        'coupon'         => $coupon ?: 'none',
        'source'         => 'molvrix_website',
    ],
];

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($orderData),
    CURLOPT_USERPWD        => RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
]);
$result = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$order = json_decode($result, true);

if ($httpCode !== 200 || empty($order['id'])) {
    error_log('Razorpay order creation failed: ' . $result);
    http_response_code(502);
    echo json_encode(['error' => 'Payment gateway error. Please try again.']);
    exit;
}

echo json_encode([
    'success'       => true,
    'razorpay_order_id' => $order['id'],
    'amount'        => $amountPaise,
    'currency'      => CURRENCY,
    'subtotal'      => $subtotal,
    'discount'      => $discount,
    'total'         => $total,
    'coupon_valid'  => $couponMeta !== null,
    'coupon_label'  => $couponMeta ? ($couponMeta['description'] ?: $coupon) : null,
]);
