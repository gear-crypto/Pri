<?php
/**
 * MOLVRIX — Multi-Model AI Query Engine
 * POST /api/ai-query.php
 * Calls Claude + Gemini + GPT simultaneously, then synthesises via Claude
 */
header('Content-Type: application/json');
// FIX: Restrict CORS to known origins — was reflecting any origin (wildcard)
$origin  = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = ['http://localhost', 'http://127.0.0.1', 'https://molvrix.com'];
$corsOrigin = in_array($origin, $allowed) ? $origin : 'https://molvrix.com';
header('Access-Control-Allow-Origin: ' . $corsOrigin);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error'=>'Method not allowed']); exit; }

require_once __DIR__ . '/logger.php';

// ── Load keys from config file or env ──
$cfgFile = __DIR__ . '/../data/ai-config.json';
$cfg     = file_exists($cfgFile) ? json_decode(file_get_contents($cfgFile), true) : [];

// ── Auth: require the same admin token as ai-apply.php and upload.php ──
// Panel sends it as X-Admin-Token header. Without this, anyone could
// call this endpoint and burn your Claude/Gemini/OpenAI credits.
$reqToken = $_SERVER['HTTP_X_ADMIN_TOKEN'] ?? '';
$stored   = $cfg['admin_token'] ?? '';
if (!$stored || !hash_equals($stored, $reqToken)) {
    MolvrixLog::write('security', 'Unauthorized ai-query attempt', ['token_provided' => !empty($reqToken)]);
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

define('CLAUDE_KEY',  $cfg['claude_key']  ?? getenv('CLAUDE_KEY')  ?? '');
define('GEMINI_KEY',  $cfg['gemini_key']  ?? getenv('GEMINI_KEY')  ?? '');
define('OPENAI_KEY',  $cfg['openai_key']  ?? getenv('OPENAI_KEY')  ?? '');
define('CLAUDE_MODEL', $cfg['claude_model'] ?? 'claude-sonnet-4-20250514');
define('GEMINI_MODEL', $cfg['gemini_model'] ?? 'gemini-2.0-flash');
define('OPENAI_MODEL', $cfg['openai_model'] ?? 'gpt-4o');

$body    = json_decode(file_get_contents('php://input'), true);
$message = trim($body['message'] ?? '');
$mode    = $body['mode']    ?? 'merge';   // 'merge' | 'claude' | 'gemini' | 'openai'
$context = $body['context'] ?? '';        // optional: file contents, error logs etc.
$history = $body['history'] ?? [];        // previous messages [{role,content}]

if (!$message) { http_response_code(400); echo json_encode(['error'=>'No message provided']); exit; }

// ── Rate limiting: max 20 requests per IP per hour ──
$ip       = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateDir  = sys_get_temp_dir() . '/molvrix_ai_rl';
if (!is_dir($rateDir)) @mkdir($rateDir, 0700, true);
$rateFile = $rateDir . '/' . md5($ip) . '.json';
$window   = 3600; $maxHits = 20; $now = time();
$hits     = [];
if (file_exists($rateFile)) {
    $hits = json_decode(file_get_contents($rateFile), true) ?: [];
}
$hits = array_filter($hits, fn($t) => $t > $now - $window);
if (count($hits) >= $maxHits) {
    MolvrixLog::write('security', 'AI rate limit exceeded', ['ip' => $ip, 'hits' => count($hits)]);
    http_response_code(429);
    echo json_encode(['error' => 'Rate limit exceeded. Max 20 AI requests per hour.']);
    exit;
}
$hits[] = $now;
file_put_contents($rateFile, json_encode(array_values($hits)), LOCK_EX);

// ── Input length guard ──
if (strlen($message) > 8000) { http_response_code(400); echo json_encode(['error'=>'Message too long (max 8000 chars)']); exit; }
if (strlen($context) > 20000) { $context = substr($context, 0, 20000) . "\n...[truncated]"; }

// Build system prompt
$systemPrompt = <<<SYSPROMPT
You are MOLVRIX AI Assistant — an expert full-stack developer and digital product specialist embedded in the MOLVRIX admin panel.

MOLVRIX is a digital products e-commerce site built with:
- Frontend: HTML/CSS/JS (vanilla), hosted as static + PHP files
- Backend: PHP APIs (razorpay-order.php, razorpay-verify.php, contact.php)
- Database: Supabase (PostgreSQL) with Row Level Security
- Payments: Razorpay
- Auth: Supabase Auth (Google, Microsoft, Twitter, Facebook, Magic Link)
- Design system: Dark theme (#0d1117 black, #2ea043 green), Syne + Space Mono + DM Mono fonts

When asked to fix bugs or add features:
1. Show the exact file path
2. Show the exact code change as a diff or full replacement
3. Explain what you changed and why
4. Flag any side effects or dependencies

Be concise, technical, and accurate. Prefer complete working code over partial snippets.
SYSPROMPT;

if ($context) $systemPrompt .= "\n\nContext provided by admin:\n" . $context;

// ── Helper: build messages array ──
function buildMessages(array $history, string $newMessage): array {
    $msgs = [];
    foreach ($history as $h) {
        if (!empty($h['role']) && !empty($h['content'])) {
            $msgs[] = ['role' => $h['role'], 'content' => $h['content']];
        }
    }
    $msgs[] = ['role' => 'user', 'content' => $newMessage];
    return $msgs;
}

// ── Call Claude ──
function callClaude(string $system, array $messages, string $model, string $key): array {
    if (!$key) return ['error' => 'Claude API key not configured', 'text' => ''];
    $payload = ['model' => $model, 'max_tokens' => 2048, 'system' => $system, 'messages' => $messages];
    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 45,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'x-api-key: ' . $key,
            'anthropic-version: 2023-06-01',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $data = json_decode($res, true);
    if ($code !== 200 || empty($data['content'][0]['text'])) {
        return ['error' => $data['error']['message'] ?? 'Claude error', 'text' => ''];
    }
    return ['text' => $data['content'][0]['text'], 'model' => CLAUDE_MODEL];
}

// ── Call Gemini ──
function callGemini(string $system, array $messages, string $model, string $key): array {
    if (!$key) return ['error' => 'Gemini API key not configured', 'text' => ''];
    // Convert to Gemini format
    $contents = [];
    foreach ($messages as $m) {
        $role = $m['role'] === 'assistant' ? 'model' : 'user';
        $contents[] = ['role' => $role, 'parts' => [['text' => $m['content']]]];
    }
    $payload = [
        'system_instruction' => ['parts' => [['text' => $system]]],
        'contents'           => $contents,
        'generationConfig'   => ['maxOutputTokens' => 2048, 'temperature' => 0.7],
    ];
    $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$key}";
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 45,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $data = json_decode($res, true);
    $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
    if ($code !== 200 || !$text) {
        return ['error' => $data['error']['message'] ?? 'Gemini error', 'text' => ''];
    }
    return ['text' => $text, 'model' => $model];
}

// ── Call OpenAI ──
function callOpenAI(string $system, array $messages, string $model, string $key): array {
    if (!$key) return ['error' => 'OpenAI API key not configured', 'text' => ''];
    $oaiMessages = [['role' => 'system', 'content' => $system]];
    foreach ($messages as $m) $oaiMessages[] = $m;
    $payload = ['model' => $model, 'messages' => $oaiMessages, 'max_tokens' => 2048];
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 45,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $key,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $data = json_decode($res, true);
    $text = $data['choices'][0]['message']['content'] ?? '';
    if ($code !== 200 || !$text) {
        return ['error' => $data['error']['message'] ?? 'OpenAI error', 'text' => ''];
    }
    return ['text' => $text, 'model' => $model];
}

// ── Merge 3 responses via Claude ──
function mergeResponses(string $query, array $responses, string $key, string $model): string {
    $parts = [];
    foreach ($responses as $name => $r) {
        if (!empty($r['text'])) $parts[] = "=== {$name} ===\n" . $r['text'];
    }
    if (empty($parts)) return 'All AI models failed to respond. Check your API keys in AI Settings.';
    if (count($parts) === 1) return array_values($responses)[0]['text'];

    $mergePrompt = "You received these responses from multiple AI models for the query:\n\n\"$query\"\n\n"
        . implode("\n\n", $parts)
        . "\n\nYour task: Synthesise these into one SUPERIOR response that:\n"
        . "1. Takes the best insights from each model\n"
        . "2. Resolves any contradictions by choosing the most accurate answer\n"
        . "3. Produces complete, actionable, production-ready output\n"
        . "4. If code is involved, shows the final merged code (not multiple versions)\n"
        . "5. Is more comprehensive than any single response alone\n\n"
        . "Output the synthesised response directly — no meta-commentary about the merging process.";

    $merged = callClaude(
        'You are a synthesis engine. Merge multiple AI responses into one superior answer.',
        [['role' => 'user', 'content' => $mergePrompt]],
        $model,
        $key
    );
    return $merged['text'] ?: implode("\n\n---\n\n", array_column(array_values($responses), 'text'));
}

// ── Execute based on mode ──
$messages = buildMessages($history, $message);
$result   = [];

if ($mode === 'claude') {
    $r = callClaude($systemPrompt, $messages, CLAUDE_MODEL, CLAUDE_KEY);
    echo json_encode(['success' => true, 'mode' => 'claude', 'response' => $r['text'] ?: $r['error'], 'sources' => ['claude' => $r]]);
    exit;
}
if ($mode === 'gemini') {
    $r = callGemini($systemPrompt, $messages, GEMINI_MODEL, GEMINI_KEY);
    echo json_encode(['success' => true, 'mode' => 'gemini', 'response' => $r['text'] ?: $r['error'], 'sources' => ['gemini' => $r]]);
    exit;
}
if ($mode === 'openai') {
    $r = callOpenAI($systemPrompt, $messages, OPENAI_MODEL, OPENAI_KEY);
    echo json_encode(['success' => true, 'mode' => 'openai', 'response' => $r['text'] ?: $r['error'], 'sources' => ['openai' => $r]]);
    exit;
}

// ── MERGE MODE: parallel calls ──
$mh = curl_multi_init();
$handles = [];

// Claude handle
if (CLAUDE_KEY) {
    $payload = json_encode(['model'=>CLAUDE_MODEL,'max_tokens'=>2048,'system'=>$systemPrompt,'messages'=>$messages]);
    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$payload,CURLOPT_TIMEOUT=>45,CURLOPT_HTTPHEADER=>['Content-Type: application/json','x-api-key: '.CLAUDE_KEY,'anthropic-version: 2023-06-01']]);
    $handles['claude'] = $ch;
    curl_multi_add_handle($mh, $ch);
}

// Gemini handle
if (GEMINI_KEY) {
    $gContents = array_map(fn($m)=>['role'=>$m['role']==='assistant'?'model':'user','parts'=>[['text'=>$m['content']]]], $messages);
    $payload = json_encode(['system_instruction'=>['parts'=>[['text'=>$systemPrompt]]],'contents'=>$gContents,'generationConfig'=>['maxOutputTokens'=>2048]]);
    $url = "https://generativelanguage.googleapis.com/v1beta/models/".GEMINI_MODEL.":generateContent?key=".GEMINI_KEY;
    $ch  = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$payload,CURLOPT_TIMEOUT=>45,CURLOPT_HTTPHEADER=>['Content-Type: application/json']]);
    $handles['gemini'] = $ch;
    curl_multi_add_handle($mh, $ch);
}

// OpenAI handle
if (OPENAI_KEY) {
    $oaiMsgs = [['role'=>'system','content'=>$systemPrompt]];
    foreach ($messages as $m) $oaiMsgs[] = $m;
    $payload = json_encode(['model'=>OPENAI_MODEL,'messages'=>$oaiMsgs,'max_tokens'=>2048]);
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$payload,CURLOPT_TIMEOUT=>45,CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.OPENAI_KEY]]);
    $handles['openai'] = $ch;
    curl_multi_add_handle($mh, $ch);
}

if (empty($handles)) {
    echo json_encode(['success'=>false,'error'=>'No AI API keys configured. Go to Admin → AI Settings.']);
    exit;
}

// Execute all in parallel
$running = null;
do { curl_multi_exec($mh, $running); } while ($running);

// Parse results
$sources = [];
foreach ($handles as $name => $ch) {
    $res  = curl_multi_getcontent($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $data = json_decode($res, true);
    if ($name === 'claude')  $sources[$name] = ['text' => $data['content'][0]['text'] ?? '', 'error' => $data['error']['message'] ?? ($code !== 200 ? 'HTTP '.$code : '')];
    if ($name === 'gemini')  $sources[$name] = ['text' => $data['candidates'][0]['content']['parts'][0]['text'] ?? '', 'error' => $data['error']['message'] ?? ($code !== 200 ? 'HTTP '.$code : '')];
    if ($name === 'openai')  $sources[$name] = ['text' => $data['choices'][0]['message']['content'] ?? '', 'error' => $data['error']['message'] ?? ($code !== 200 ? 'HTTP '.$code : '')];
    curl_multi_remove_handle($mh, $ch);
}
curl_multi_close($mh);

// Merge via Claude
$merged = mergeResponses($message, $sources, CLAUDE_KEY ?: OPENAI_KEY, CLAUDE_MODEL);

echo json_encode([
    'success'  => true,
    'mode'     => 'merge',
    'response' => $merged,
    'sources'  => $sources,  // individual model responses (shown in panel)
]);
