<?php
/**
 * MOLVRIX — Environment Config Helper
 *
 * USAGE (add to top of razorpay-order.php, razorpay-verify.php):
 *   require_once __DIR__ . '/env.php';
 *   // Then use: molvrix_env('SUPABASE_URL'), molvrix_env('RAZORPAY_KEY_SECRET') etc.
 *
 * SETUP OPTIONS (pick one):
 *
 * Option A — Server environment variables (most secure):
 *   In cPanel → Software → PHP Config, or your server's .bashrc / systemd unit:
 *   SUPABASE_URL=https://...
 *   SUPABASE_SERVICE_KEY=eyJ...
 *   RAZORPAY_KEY_ID=rzp_live_...
 *   RAZORPAY_KEY_SECRET=...
 *
 * Option B — .env file outside web root (good for shared hosting):
 *   Create /home/youraccount/.env (one level above public_html)
 *   Copy values from .env.example
 *   Update $envFile path below.
 *
 * Option C — Hard-coded (least secure, acceptable for private servers):
 *   Keep your values directly in razorpay-*.php as before.
 *   This file is then not needed.
 */

function molvrix_env(string $key, string $default = ''): string {
    // 1. Check actual environment variables (set via server/hosting panel)
    $val = getenv($key);
    if ($val !== false && $val !== '') return $val;

    // 2. Check .env file outside web root
    static $parsed = null;
    if ($parsed === null) {
        $parsed = [];
        // Adjust this path to point to your .env file
        $envFile = dirname(__DIR__, 2) . '/.env'; // 2 levels up from /api/
        if (!file_exists($envFile)) {
            // Fallback: same directory as this file
            $envFile = __DIR__ . '/../.env';
        }
        if (file_exists($envFile)) {
            foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#') continue;
                if (strpos($line, '=') === false) continue;
                [$k, $v] = explode('=', $line, 2);
                $parsed[trim($k)] = trim($v);
            }
        }
    }

    return $parsed[$key] ?? $default;
}
