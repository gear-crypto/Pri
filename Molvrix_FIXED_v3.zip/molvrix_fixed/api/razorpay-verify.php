<?php
/**
 * MOLVRIX — Razorpay Payment Verifier
 * POST /api/razorpay-verify.php
 * Body: { razorpay_order_id, razorpay_payment_id, razorpay_signature,
 *         items, email, name, user_id?, coupon?, discount?, total }
 */
// ── CORS: only allow requests from the site's own origin ──
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = [
    'http://localhost',
    'http://127.0.0.1',
    'https://molvrix.com',
];
$corsOrigin = in_array($origin, $allowed) ? $origin : ($allowed[2] ?? '*');
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . $corsOrigin);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST')    { http_response_code(405); echo json_encode(['error'=>'Method not allowed']); exit; }

// ══════════════════════════════════════════════════════
// Secrets loaded from environment / .env file (not hard-coded)
// See api/env.php for setup instructions.
// ══════════════════════════════════════════════════════
require_once __DIR__ . '/env.php';
require_once __DIR__ . '/logger.php';
define('RAZORPAY_KEY_SECRET', molvrix_env('RAZORPAY_KEY_SECRET', 'YOUR_RAZORPAY_SECRET'));
define('SUPABASE_URL',        molvrix_env('SUPABASE_URL',        'https://mrajnjxbudjyrdfmmape.supabase.co'));
define('SUPABASE_SERVICE_KEY', molvrix_env('SUPABASE_SERVICE_KEY', ''));

$body       = json_decode(file_get_contents('php://input'), true);
$orderId    = $body['razorpay_order_id']    ?? '';
$paymentId  = $body['razorpay_payment_id']  ?? '';
$signature  = $body['razorpay_signature']   ?? '';
$items      = $body['items']   ?? [];
$email      = htmlspecialchars(trim($body['email']  ?? ''));
$name       = htmlspecialchars(trim($body['name']   ?? 'Customer'));
$userId     = $body['user_id'] ?? null;
$coupon     = strtoupper(trim($body['coupon'] ?? ''));
$discount   = floatval($body['discount'] ?? 0);
$total      = floatval($body['total']    ?? 0);

if (!$orderId || !$paymentId || !$signature) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing payment verification data']);
    exit;
}

// ── Verify Razorpay signature ──
$expectedSig = hash_hmac('sha256', $orderId . '|' . $paymentId, RAZORPAY_KEY_SECRET);
if (!hash_equals($expectedSig, $signature)) {
    http_response_code(400);
    MolvrixLog::write('security', 'Payment signature verification failed', ['order_id' => $orderId, 'payment_id' => $paymentId]);
    echo json_encode(['error' => 'Payment signature verification failed. Do not proceed.']);
    exit;
}

// ── Idempotency: check this payment_id hasn't already been recorded ──
$dupCheck = curl_init(SUPABASE_URL . '/rest/v1/orders?razorpay_payment_id=eq.' . urlencode($paymentId) . '&select=id&limit=1');
curl_setopt_array($dupCheck, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'apikey: ' . SUPABASE_SERVICE_KEY,
        'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
    ],
]);
$dupResp = json_decode(curl_exec($dupCheck), true);
curl_close($dupCheck);
if (!empty($dupResp)) {
    // Already recorded — return success silently (idempotent)
    echo json_encode(['success' => true, 'order_id' => $dupResp[0]['id'], 'payment_id' => $paymentId, 'message' => 'Already recorded.']);
    exit;
}

// ── Record order in Supabase ──
$orderRecord = [
    'user_id'             => $userId,
    'user_email'          => $email,
    'user_name'           => $name,
    'razorpay_order_id'   => $orderId,
    'razorpay_payment_id' => $paymentId,
    'razorpay_signature'  => $signature,
    'amount'              => $total,
    'currency'            => 'INR',
    'status'              => 'paid',
    'items'               => json_encode($items),
    'coupon_code'         => $coupon ?: null,
    'discount'            => $discount,
];

$ch = curl_init(SUPABASE_URL . '/rest/v1/orders');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($orderRecord),
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'apikey: ' . SUPABASE_SERVICE_KEY,
        'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
        'Prefer: return=representation',
    ],
]);
$resp = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$savedOrders = json_decode($resp, true);
$savedOrder  = $savedOrders[0] ?? null;

// Log if order insert failed but NEVER block payment success response
// Payment is verified — user paid. Always grant access even if DB write fails.
if (!$savedOrder) {
    error_log('MOLVRIX: Order DB insert failed for payment ' . $paymentId . ' | HTTP ' . $httpCode . ' | ' . $resp);
    MolvrixLog::write('error', 'Order DB insert failed', ['payment_id' => $paymentId, 'http_code' => $httpCode, 'response' => substr($resp, 0, 300)]);
}

// ── If user is logged in, record downloads ──
if ($userId && $savedOrder) {
    foreach ($items as $item) {
        // Skip bundle IDs that don't exist in products table (FK constraint)
        // Bundle purchases are tracked in orders table only
        if (strpos($item['id'], 'bundle-') === 0) continue;

        $dl = [
            'user_id'    => $userId,
            'product_id' => $item['id'],
            'order_id'   => $savedOrder['id'],
        ];
        $ch = curl_init(SUPABASE_URL . '/rest/v1/downloads');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($dl),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'apikey: ' . SUPABASE_SERVICE_KEY,
                'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
                'Prefer: resolution=ignore-duplicates',
            ],
        ]);
        $dlResp = curl_exec($ch);
        $dlCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($dlCode >= 400) {
            error_log('MOLVRIX: Failed to record download for product ' . $item['id'] . ': ' . $dlResp);
        }
    }

    // ── Increment coupon used_count via RPC ──
    if ($coupon) {
        // Use Supabase RPC to atomically increment — REST PATCH cannot do arithmetic
        $ch = curl_init(SUPABASE_URL . '/rest/v1/rpc/increment_coupon_usage');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode(['p_code' => $coupon]),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'apikey: '          . SUPABASE_SERVICE_KEY,
                'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
            ],
        ]);
        curl_exec($ch);
        curl_close($ch);
        // RPC SQL (add to Supabase SQL Editor):
        // CREATE OR REPLACE FUNCTION increment_coupon_usage(p_code TEXT)
        // RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER AS $$
        // BEGIN
        //   UPDATE coupons SET used_count = used_count + 1 WHERE code = p_code;
        // END; $$;
    }
}

// ── Track affiliate commission via Supabase RPC ──
$affiliate = $body['affiliate'] ?? null;
if ($affiliate && $savedOrder) {
    // Use Supabase RPC function to atomically increment affiliate totals
    $rpcPayload = json_encode([
        'p_code'  => $affiliate,
        'p_sale'  => $total,
        'p_earn'  => round($total * 0.30, 2), // 30% default commission
    ]);
    $ch = curl_init(SUPABASE_URL . '/rest/v1/rpc/increment_affiliate_stats');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $rpcPayload,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'apikey: ' . SUPABASE_SERVICE_KEY,
            'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
        ],
    ]);
    curl_exec($ch);
    curl_close($ch);
    // Note: create this RPC in Supabase SQL editor:
    // CREATE OR REPLACE FUNCTION increment_affiliate_stats(p_code TEXT, p_sale NUMERIC, p_earn NUMERIC)
    // RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER AS $$
    // BEGIN
    //   UPDATE affiliates SET total_sales = total_sales + p_sale,
    //     total_earnings = total_earnings + p_earn, payout_due = payout_due + p_earn
    //   WHERE code = p_code AND status = 'active';
    // END; $$;
}

MolvrixLog::write('payment', 'Payment verified and recorded', [
    'payment_id' => $paymentId,
    'order_id'   => $savedOrder['id'] ?? null,
    'amount'     => $total,
    'email'      => $email,
    'items'      => count($items),
    'coupon'     => $coupon ?: null,
]);

echo json_encode([
    'success'    => true,
    'order_id'   => $savedOrder['id'] ?? null,
    'payment_id' => $paymentId,
    'message'    => 'Payment verified and recorded.',
]);
