<?php
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error'=>'Method not allowed']); exit;
}

require_once __DIR__ . '/logger.php';

// ── Honeypot: bots fill the website field, humans leave it blank ──
$honeypot = $_POST['website'] ?? '';
if (!empty($honeypot)) {
    // Silently succeed so bots don't know they were blocked
    echo json_encode(['success'=>true, 'message'=>'Message sent successfully!']); exit;
}

// ── Session-based rate limit: max 3 submissions per hour per IP ──
if (session_status() === PHP_SESSION_NONE) session_start();
$ip       = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$key      = 'contact_hits_' . md5($ip);
$window   = 3600; // 1 hour
$maxHits  = 3;
$now      = time();
$hits     = $_SESSION[$key] ?? [];
// Remove entries older than the window
$hits = array_filter($hits, fn($t) => $t > $now - $window);
if (count($hits) >= $maxHits) {
    MolvrixLog::write('security', 'Contact form rate limit hit', ['ip' => $ip]);
    http_response_code(429);
    echo json_encode(['error' => 'Too many requests. Please wait before sending another message.']);
    exit;
}
$hits[] = $now;
$_SESSION[$key] = array_values($hits);

// ── Input sanitisation ──
$name    = htmlspecialchars(trim($_POST['name']    ?? ''));
$email   = htmlspecialchars(trim($_POST['email']   ?? ''));
$subject = htmlspecialchars(trim($_POST['subject'] ?? ''));
$message = htmlspecialchars(trim($_POST['message'] ?? ''));

if (!$name || !$email || !$message) {
    http_response_code(400); echo json_encode(['error'=>'Missing required fields']); exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400); echo json_encode(['error'=>'Invalid email address']); exit;
}
if (strlen($message) < 10) {
    http_response_code(400); echo json_encode(['error'=>'Message too short']); exit;
}
if (strlen($message) > 5000) {
    http_response_code(400); echo json_encode(['error'=>'Message too long (max 5000 chars)']); exit;
}

// ── CSRF: verify same-origin referer ──
$host = $_SERVER['HTTP_HOST'] ?? '';
$ref  = $_SERVER['HTTP_REFERER'] ?? '';
if ($host && $ref && strpos($ref, $host) === false) {
    http_response_code(403); echo json_encode(['error'=>'Forbidden']); exit;
}

// ── Send email ──
$to      = 'molvrixsupport@gmail.com';
$headers = "From: noreply@{$host}\r\nReply-To: {$email}\r\nContent-Type: text/plain; charset=UTF-8";
$body    = "Name: {$name}\nEmail: {$email}\nSubject: {$subject}\n\nMessage:\n{$message}\n\n---\nIP: {$ip}\nTime: " . date('Y-m-d H:i:s T');

if (mail($to, "MOLVRIX Contact: {$subject}", $body, $headers)) {
    MolvrixLog::write('activity', 'Contact form submitted', ['name' => $name, 'email' => $email, 'subject' => $subject]);
    echo json_encode(['success'=>true, 'message'=>'Message sent successfully!']);
} else {
    MolvrixLog::write('error', 'Contact form mail() failed', ['email' => $email, 'subject' => $subject]);
    http_response_code(500);
    echo json_encode(['error'=>'Failed to send. Please email us directly at molvrixsupport@gmail.com']);
}
