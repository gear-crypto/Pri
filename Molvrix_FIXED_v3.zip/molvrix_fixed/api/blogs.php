<?php
/**
 * MOLVRIX Blogs API
 * Tries Supabase first, falls back to data/blogs.json
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

define('SUPABASE_URL',  'https://mrajnjxbudjyrdfmmape.supabase.co');
define('SUPABASE_ANON', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1yYWpuanhidWRqeXJkZm1tYXBlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM2Mjg2NzAsImV4cCI6MjA4OTIwNDY3MH0.Wv7hUjhC-TgBxwl3xMGKVLKb02awpUjkLORKftHgr2M');

if (true) { // Supabase configured
    $ch = curl_init(SUPABASE_URL . '/rest/v1/blogs?published=eq.true&order=created_at.desc&select=*');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 4,
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_ANON,
            'Authorization: Bearer ' . SUPABASE_ANON,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code === 200 && $res) { echo $res; exit; }
}

$file = __DIR__ . '/../data/blogs.json';
echo file_exists($file) ? file_get_contents($file) : '[]';
