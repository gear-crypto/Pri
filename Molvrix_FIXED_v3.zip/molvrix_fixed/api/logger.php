<?php
/**
 * MOLVRIX — Logging Engine
 * Include this in any PHP file: require_once __DIR__ . '/logger.php';
 * (or require_once __DIR__ . '/../api/logger.php' from admin files)
 *
 * Categories:
 *   'payment'  — successful payments, failed verifications
 *   'error'    — PHP errors, API failures, DB write failures
 *   'security' — auth failures, rate limit hits, CSRF blocks, suspicious requests
 *   'activity' — contact form submissions, newsletter signups, admin actions
 *
 * Usage:
 *   MolvrixLog::write('payment', 'Payment verified', ['payment_id' => $pid, 'amount' => 999]);
 *   MolvrixLog::write('error',   'DB insert failed', ['response' => $resp]);
 *   MolvrixLog::write('security','Rate limit hit',   ['ip' => $ip]);
 */

class MolvrixLog {

    // Log files live in /data/logs/ — already blocked from web by .htaccess
    private static function logDir(): string {
        $dir = dirname(__DIR__) . '/data/logs';
        if (!is_dir($dir)) mkdir($dir, 0750, true);
        return $dir;
    }

    /**
     * Write a log entry.
     *
     * @param string $category  payment | error | security | activity
     * @param string $message   Human-readable description
     * @param array  $context   Extra data (payment_id, ip, file, etc.)
     */
    public static function write(string $category, string $message, array $context = []): void {
        $allowed = ['payment', 'error', 'security', 'activity'];
        if (!in_array($category, $allowed)) $category = 'activity';

        $ip = $_SERVER['HTTP_CF_CONNECTING_IP']
            ?? $_SERVER['HTTP_X_FORWARDED_FOR']
            ?? $_SERVER['REMOTE_ADDR']
            ?? 'unknown';

        $entry = [
            'ts'       => date('Y-m-d H:i:s'),
            'ts_unix'  => time(),
            'category' => $category,
            'message'  => $message,
            'ip'       => $ip,
            'url'      => $_SERVER['REQUEST_URI'] ?? '',
            'method'   => $_SERVER['REQUEST_METHOD'] ?? '',
            'context'  => $context,
        ];

        // One file per category per day: payment-2026-03-19.log
        $filename = $category . '-' . date('Y-m-d') . '.log';
        $path     = self::logDir() . '/' . $filename;

        // Append as newline-delimited JSON (easy to tail, parse, grep)
        @file_put_contents($path, json_encode($entry) . "\n", FILE_APPEND | LOCK_EX);
    }

    /**
     * Read log entries, optionally filtered.
     *
     * @param string $category  payment | error | security | activity | all
     * @param int    $days      How many days back to read (default 7)
     * @param int    $limit     Max entries to return (default 200, newest first)
     * @return array
     */
    public static function read(string $category = 'all', int $days = 7, int $limit = 200): array {
        $dir     = self::logDir();
        $entries = [];
        $cats    = $category === 'all' ? ['payment', 'error', 'security', 'activity'] : [$category];

        for ($d = 0; $d < $days; $d++) {
            $date = date('Y-m-d', strtotime("-{$d} days"));
            foreach ($cats as $cat) {
                $path = $dir . '/' . $cat . '-' . $date . '.log';
                if (!file_exists($path)) continue;
                $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                if (!$lines) continue;
                foreach (array_reverse($lines) as $line) {
                    $decoded = json_decode($line, true);
                    if ($decoded) $entries[] = $decoded;
                }
            }
        }

        // Sort newest first
        usort($entries, fn($a, $b) => $b['ts_unix'] - $a['ts_unix']);

        return array_slice($entries, 0, $limit);
    }

    /**
     * Get summary counts per category for the last N days.
     */
    public static function summary(int $days = 7): array {
        $dir     = self::logDir();
        $summary = ['payment' => 0, 'error' => 0, 'security' => 0, 'activity' => 0];

        for ($d = 0; $d < $days; $d++) {
            $date = date('Y-m-d', strtotime("-{$d} days"));
            foreach (array_keys($summary) as $cat) {
                $path = $dir . '/' . $cat . '-' . $date . '.log';
                if (!file_exists($path)) continue;
                $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                $summary[$cat] += count($lines ?: []);
            }
        }

        return $summary;
    }

    /**
     * Delete log files older than $days.
     */
    public static function purge(int $keepDays = 30): int {
        $dir     = self::logDir();
        $deleted = 0;
        $cutoff  = strtotime("-{$keepDays} days");

        foreach (glob($dir . '/*.log') as $file) {
            // Extract date from filename: payment-2026-03-01.log
            if (preg_match('/(\d{4}-\d{2}-\d{2})\.log$/', $file, $m)) {
                if (strtotime($m[1]) < $cutoff) {
                    unlink($file);
                    $deleted++;
                }
            }
        }

        return $deleted;
    }
}
