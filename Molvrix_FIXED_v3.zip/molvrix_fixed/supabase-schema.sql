-- ═══════════════════════════════════════════════════════════
--  MOLVRIX — Supabase Schema
--  Run this in: Supabase Dashboard → SQL Editor → New Query
-- ═══════════════════════════════════════════════════════════

-- ── Enable UUID extension ──
CREATE EXTENSION IF NOT EXISTS "pgcrypto";


-- ── 1. PROFILES ─────────────────────────────────────────────
-- Extends Supabase auth.users automatically via trigger
CREATE TABLE IF NOT EXISTS profiles (
  id            UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email         TEXT,
  full_name     TEXT,
  avatar_url    TEXT,
  role          TEXT NOT NULL DEFAULT 'customer',  -- 'customer' | 'admin' | 'superadmin'
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO profiles (id, email, full_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'avatar_url'
  ) ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();


-- ── 2. PRODUCTS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
  id             TEXT PRIMARY KEY,
  name           TEXT NOT NULL,
  category       TEXT NOT NULL,
  icon           TEXT,                     -- kept for fallback
  illustration   TEXT,                     -- SVG key from illustrations.js
  price          NUMERIC(10,2) NOT NULL,
  original_price NUMERIC(10,2),
  badge          TEXT,                     -- 'hot' | 'new' | 'sale' | null
  description    TEXT,
  includes       JSONB DEFAULT '[]',
  thumb_bg       TEXT,
  thumb_code     TEXT,
  download_url   TEXT,                     -- actual file URL (Supabase Storage or external)
  thumbnail      TEXT,                     -- product card image (Supabase Storage URL or base64)
  active         BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order     INTEGER DEFAULT 0,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- ── 3. ORDERS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             UUID REFERENCES auth.users ON DELETE SET NULL,
  user_email          TEXT NOT NULL,
  user_name           TEXT,
  razorpay_order_id   TEXT UNIQUE,
  razorpay_payment_id TEXT,
  razorpay_signature  TEXT,
  amount              NUMERIC(10,2) NOT NULL,         -- in currency units (not paise)
  currency            TEXT NOT NULL DEFAULT 'INR',
  status              TEXT NOT NULL DEFAULT 'pending', -- 'pending'|'paid'|'failed'|'refunded'
  items               JSONB NOT NULL DEFAULT '[]',     -- [{id,name,price}]
  coupon_code         TEXT,
  discount            NUMERIC(10,2) DEFAULT 0,
  affiliate_code      TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- ── 4. DOWNLOADS ────────────────────────────────────────────
-- Tracks what each user has purchased / can download
CREATE TABLE IF NOT EXISTS downloads (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  product_id     TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  order_id       UUID REFERENCES orders(id) ON DELETE SET NULL,
  download_count INTEGER NOT NULL DEFAULT 0,
  last_downloaded TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, product_id)
);


-- ── 5. BLOGS ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS blogs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug        TEXT UNIQUE NOT NULL,
  title       TEXT NOT NULL,
  excerpt     TEXT,
  content     TEXT,
  category    TEXT,
  author_id   UUID REFERENCES auth.users ON DELETE SET NULL,
  author_name TEXT NOT NULL DEFAULT 'MOLVRIX Team',
  featured    BOOLEAN NOT NULL DEFAULT FALSE,
  published   BOOLEAN NOT NULL DEFAULT FALSE,
  cover_emoji TEXT DEFAULT 'docs',
  cover_image TEXT,                     -- uploaded cover photo URL
  read_time   TEXT DEFAULT '5 min read',
  views       INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- ── 6. TESTIMONIALS ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS testimonials (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  role        TEXT,
  company     TEXT,
  content     TEXT NOT NULL,
  rating      INTEGER NOT NULL DEFAULT 5 CHECK (rating BETWEEN 1 AND 5),
  avatar_url  TEXT,
  product_id  TEXT REFERENCES products(id) ON DELETE SET NULL,
  approved    BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- ── 7. AFFILIATES ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS affiliates (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id            UUID REFERENCES auth.users ON DELETE SET NULL,
  name               TEXT NOT NULL,
  email              TEXT UNIQUE NOT NULL,
  code               TEXT UNIQUE NOT NULL,
  commission_percent NUMERIC(5,2) NOT NULL DEFAULT 30,
  total_sales        NUMERIC(10,2) NOT NULL DEFAULT 0,
  total_earnings     NUMERIC(10,2) NOT NULL DEFAULT 0,
  payout_due         NUMERIC(10,2) NOT NULL DEFAULT 0,
  status             TEXT NOT NULL DEFAULT 'active',  -- 'active'|'paused'|'banned'
  notes              TEXT,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- ── 8. COUPONS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS coupons (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code        TEXT UNIQUE NOT NULL,
  type        TEXT NOT NULL CHECK (type IN ('percent','fixed')),
  value       NUMERIC(10,2) NOT NULL,
  min_order   NUMERIC(10,2) NOT NULL DEFAULT 0,
  max_uses    INTEGER,                  -- null = unlimited
  used_count  INTEGER NOT NULL DEFAULT 0,
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  expires_at  TIMESTAMPTZ,
  description TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Seed demo coupons
INSERT INTO coupons (code, type, value, description) VALUES
  ('LAUNCH20',  'percent', 20, '20% launch discount'),
  ('WELCOME10', 'percent', 10, '10% welcome offer'),
  ('FLAT500',   'fixed',   500, '₹500 flat off'),
  ('FOUNDERS',  'percent', 25, '25% founders deal')
ON CONFLICT (code) DO NOTHING;


-- ── ROW LEVEL SECURITY ──────────────────────────────────────

ALTER TABLE profiles      ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders        ENABLE ROW LEVEL SECURITY;
ALTER TABLE downloads     ENABLE ROW LEVEL SECURITY;
ALTER TABLE testimonials  ENABLE ROW LEVEL SECURITY;

-- Profiles: users see own row; admins see all
CREATE POLICY "profiles_self"  ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles_admin" ON profiles FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','superadmin'))
);

-- Orders: users see own orders
CREATE POLICY "orders_self"  ON orders FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "orders_admin" ON orders FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','superadmin'))
);

-- Downloads: users see own downloads
CREATE POLICY "downloads_self"  ON downloads FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "downloads_admin" ON downloads FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','superadmin'))
);

-- Products: public read, admin write
CREATE POLICY "products_public_read"  ON products FOR SELECT USING (active = TRUE);
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products_admin_write" ON products FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','superadmin'))
);

-- Blogs: public read of published; admin full access
ALTER TABLE blogs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "blogs_public_read" ON blogs FOR SELECT USING (published = TRUE);
CREATE POLICY "blogs_admin"       ON blogs FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','superadmin'))
);

-- Coupons: service role only (PHP backend reads them)
ALTER TABLE coupons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "coupons_admin" ON coupons FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','superadmin'))
);

-- Affiliates: self + admin
ALTER TABLE affiliates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "affiliates_self"  ON affiliates FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "affiliates_admin" ON affiliates FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','superadmin'))
);

-- Testimonials: public read approved; admin full access; users insert own
CREATE POLICY "testi_public"  ON testimonials FOR SELECT USING (approved = TRUE);
CREATE POLICY "testi_insert"  ON testimonials FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "testi_admin"   ON testimonials FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','superadmin'))
);


-- ── HELPER FUNCTION: make user admin ────────────────────────
-- Run this manually: SELECT make_admin('user@email.com');
CREATE OR REPLACE FUNCTION make_admin(p_email TEXT)
RETURNS TEXT LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE profiles SET role = 'admin'
  WHERE email = p_email;
  IF FOUND THEN RETURN 'OK: ' || p_email || ' is now admin';
  ELSE RETURN 'ERROR: user not found';
  END IF;
END;
$$;


-- ── AFFILIATE STATS INCREMENT (called by razorpay-verify.php) ────────────────
-- Run this in Supabase SQL Editor after creating the affiliates table
CREATE OR REPLACE FUNCTION increment_affiliate_stats(
    p_code  TEXT,
    p_sale  NUMERIC,
    p_earn  NUMERIC
)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    UPDATE affiliates
    SET
        total_sales    = total_sales    + p_sale,
        total_earnings = total_earnings + p_earn,
        payout_due     = payout_due     + p_earn,
        updated_at     = NOW()
    WHERE code = p_code AND status = 'active';
END;
$$;


-- ── COUPON USAGE INCREMENT (called by razorpay-verify.php) ──────────────────
CREATE OR REPLACE FUNCTION increment_coupon_usage(p_code TEXT)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    UPDATE coupons SET used_count = used_count + 1 WHERE code = p_code;
END;
$$;
