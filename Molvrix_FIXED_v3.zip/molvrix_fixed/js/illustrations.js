/* ═══════════════════════════════════════════
   MOLVRIX — SVG Illustrations
   Abstract geometric art per category/product
   Replaces emoji on product cards
═══════════════════════════════════════════ */

const ILLUSTRATIONS = {

  /* ── Category illustrations ─────────────── */

  Automation: `<svg viewBox="0 0 120 90" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="g-auto" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#2ea043" stop-opacity="0.9"/>
        <stop offset="100%" stop-color="#1a7f37" stop-opacity="0.5"/>
      </linearGradient>
    </defs>
    <!-- nodes -->
    <circle cx="20" cy="45" r="8" fill="none" stroke="#2ea043" stroke-width="1.5" opacity="0.9"/>
    <circle cx="60" cy="20" r="8" fill="none" stroke="#2ea043" stroke-width="1.5" opacity="0.9"/>
    <circle cx="60" cy="70" r="8" fill="none" stroke="#2ea043" stroke-width="1.5" opacity="0.9"/>
    <circle cx="100" cy="45" r="8" fill="none" stroke="#3fb950" stroke-width="1.5"/>
    <!-- connectors -->
    <path d="M28 41 L52 24" stroke="#2ea043" stroke-width="1" opacity="0.5" stroke-dasharray="3,2"/>
    <path d="M28 49 L52 67" stroke="#2ea043" stroke-width="1" opacity="0.5" stroke-dasharray="3,2"/>
    <path d="M68 24 L92 41" stroke="#2ea043" stroke-width="1" opacity="0.5" stroke-dasharray="3,2"/>
    <path d="M68 67 L92 49" stroke="#2ea043" stroke-width="1" opacity="0.5" stroke-dasharray="3,2"/>
    <!-- inner fills -->
    <circle cx="20" cy="45" r="3" fill="#2ea043" opacity="0.8"/>
    <circle cx="60" cy="20" r="3" fill="#2ea043" opacity="0.8"/>
    <circle cx="60" cy="70" r="3" fill="#2ea043" opacity="0.8"/>
    <circle cx="100" cy="45" r="3" fill="#3fb950"/>
    <!-- arrow head on output -->
    <polygon points="106,45 100,41 100,49" fill="#3fb950" opacity="0.7"/>
    <!-- pulse rings -->
    <circle cx="20" cy="45" r="13" fill="none" stroke="#2ea043" stroke-width="0.5" opacity="0.25"/>
    <circle cx="100" cy="45" r="13" fill="none" stroke="#3fb950" stroke-width="0.5" opacity="0.25"/>
  </svg>`,

  Operations: `<svg viewBox="0 0 120 90" xmlns="http://www.w3.org/2000/svg">
    <!-- large gear -->
    <g transform="translate(40,45)">
      <circle r="18" fill="none" stroke="#2ea043" stroke-width="1.5" opacity="0.8"/>
      <circle r="8"  fill="none" stroke="#2ea043" stroke-width="1" opacity="0.6"/>
      <circle r="2.5" fill="#2ea043" opacity="0.9"/>
      <!-- teeth -->
      <rect x="-2.5" y="-22" width="5" height="7" rx="1" fill="#2ea043" opacity="0.7"/>
      <rect x="-2.5" y="15"  width="5" height="7" rx="1" fill="#2ea043" opacity="0.7"/>
      <rect x="-22"  y="-2.5" width="7" height="5" rx="1" fill="#2ea043" opacity="0.7"/>
      <rect x="15"   y="-2.5" width="7" height="5" rx="1" fill="#2ea043" opacity="0.7"/>
      <rect x="-17.5" y="-18" width="5" height="6" rx="1" fill="#2ea043" opacity="0.5" transform="rotate(45)"/>
      <rect x="-17.5" y="-18" width="5" height="6" rx="1" fill="#2ea043" opacity="0.5" transform="rotate(135)"/>
    </g>
    <!-- small gear -->
    <g transform="translate(82,30)">
      <circle r="11" fill="none" stroke="#3fb950" stroke-width="1.2" opacity="0.7"/>
      <circle r="4"  fill="none" stroke="#3fb950" stroke-width="0.8" opacity="0.5"/>
      <circle r="1.5" fill="#3fb950"/>
      <rect x="-1.5" y="-14" width="3" height="5" rx="0.8" fill="#3fb950" opacity="0.6"/>
      <rect x="-1.5" y="9"   width="3" height="5" rx="0.8" fill="#3fb950" opacity="0.6"/>
      <rect x="-14"  y="-1.5" width="5" height="3" rx="0.8" fill="#3fb950" opacity="0.6"/>
      <rect x="9"    y="-1.5" width="5" height="3" rx="0.8" fill="#3fb950" opacity="0.6"/>
    </g>
    <!-- tiny gear -->
    <g transform="translate(82,62)">
      <circle r="8" fill="none" stroke="#2ea043" stroke-width="1" opacity="0.5"/>
      <circle r="3" fill="none" stroke="#2ea043" stroke-width="0.7" opacity="0.4"/>
      <circle r="1" fill="#2ea043" opacity="0.6"/>
    </g>
  </svg>`,

  'AI & Copy': `<svg viewBox="0 0 120 90" xmlns="http://www.w3.org/2000/svg">
    <!-- brain outline -->
    <path d="M38 55 C22 55 18 42 25 34 C20 28 26 18 34 20 C36 13 46 10 52 16 C55 10 67 10 70 18 C78 15 86 24 82 32 C90 36 90 50 80 54 C80 65 68 70 58 65 C52 70 40 68 38 55Z" fill="none" stroke="#2ea043" stroke-width="1.3" opacity="0.7"/>
    <!-- neural dots -->
    <circle cx="45" cy="38" r="2.5" fill="#2ea043" opacity="0.9"/>
    <circle cx="60" cy="30" r="2.5" fill="#3fb950"/>
    <circle cx="72" cy="40" r="2.5" fill="#2ea043" opacity="0.9"/>
    <circle cx="48" cy="52" r="2.5" fill="#2ea043" opacity="0.7"/>
    <circle cx="64" cy="52" r="2.5" fill="#3fb950" opacity="0.8"/>
    <!-- synapses -->
    <line x1="45" y1="38" x2="60" y2="30" stroke="#2ea043" stroke-width="0.9" opacity="0.5"/>
    <line x1="60" y1="30" x2="72" y2="40" stroke="#2ea043" stroke-width="0.9" opacity="0.5"/>
    <line x1="45" y1="38" x2="48" y2="52" stroke="#2ea043" stroke-width="0.9" opacity="0.5"/>
    <line x1="72" y1="40" x2="64" y2="52" stroke="#2ea043" stroke-width="0.9" opacity="0.5"/>
    <line x1="48" y1="52" x2="64" y2="52" stroke="#2ea043" stroke-width="0.9" opacity="0.5"/>
    <line x1="60" y1="30" x2="64" y2="52" stroke="#2ea043" stroke-width="0.7" opacity="0.3"/>
    <!-- output beam -->
    <path d="M82 45 L110 45" stroke="#3fb950" stroke-width="1.5" stroke-dasharray="4,3" opacity="0.6"/>
    <polygon points="113,45 107,42 107,48" fill="#3fb950" opacity="0.7"/>
  </svg>`,

  Productivity: `<svg viewBox="0 0 120 90" xmlns="http://www.w3.org/2000/svg">
    <!-- calendar grid -->
    <rect x="20" y="18" width="80" height="60" rx="4" fill="none" stroke="#2ea043" stroke-width="1.3" opacity="0.7"/>
    <!-- header bar -->
    <rect x="20" y="18" width="80" height="14" rx="4" fill="#2ea043" opacity="0.15"/>
    <line x1="20" y1="32" x2="100" y2="32" stroke="#2ea043" stroke-width="0.8" opacity="0.5"/>
    <!-- header dots -->
    <circle cx="32" cy="25" r="3" fill="#2ea043" opacity="0.7"/>
    <circle cx="44" cy="25" r="3" fill="#3fb950" opacity="0.5"/>
    <!-- grid lines vertical -->
    <line x1="40" y1="32" x2="40" y2="78" stroke="#2ea043" stroke-width="0.5" opacity="0.25"/>
    <line x1="60" y1="32" x2="60" y2="78" stroke="#2ea043" stroke-width="0.5" opacity="0.25"/>
    <line x1="80" y1="32" x2="80" y2="78" stroke="#2ea043" stroke-width="0.5" opacity="0.25"/>
    <!-- grid lines horizontal -->
    <line x1="20" y1="46" x2="100" y2="46" stroke="#2ea043" stroke-width="0.5" opacity="0.25"/>
    <line x1="20" y1="62" x2="100" y2="62" stroke="#2ea043" stroke-width="0.5" opacity="0.25"/>
    <!-- filled cells (task blocks) -->
    <rect x="22" y="34" width="16" height="10" rx="2" fill="#2ea043" opacity="0.4"/>
    <rect x="42" y="34" width="36" height="10" rx="2" fill="#3fb950" opacity="0.3"/>
    <rect x="22" y="48" width="56" height="10" rx="2" fill="#2ea043" opacity="0.25"/>
    <rect x="82" y="48" width="16" height="10" rx="2" fill="#2ea043" opacity="0.4"/>
    <rect x="62" y="64" width="36" height="10" rx="2" fill="#3fb950" opacity="0.2"/>
    <!-- check marks -->
    <path d="M26 39 L28 41 L32 36" stroke="#3fb950" stroke-width="1.2" fill="none" stroke-linecap="round"/>
  </svg>`,

  Learning: `<svg viewBox="0 0 120 90" xmlns="http://www.w3.org/2000/svg">
    <!-- stacked book pages -->
    <rect x="28" y="58" width="64" height="10" rx="2" fill="none" stroke="#2ea043" stroke-width="1" opacity="0.4"/>
    <rect x="25" y="48" width="70" height="12" rx="2" fill="none" stroke="#2ea043" stroke-width="1.1" opacity="0.55"/>
    <rect x="22" y="36" width="76" height="14" rx="2.5" fill="none" stroke="#2ea043" stroke-width="1.3" opacity="0.75"/>
    <rect x="19" y="22" width="82" height="16" rx="3" fill="none" stroke="#3fb950" stroke-width="1.5" opacity="0.9"/>
    <!-- spine -->
    <rect x="57" y="22" width="2" height="16" fill="#2ea043" opacity="0.3"/>
    <!-- text lines on top book -->
    <line x1="27" y1="30" x2="55" y2="30" stroke="#2ea043" stroke-width="1" opacity="0.5"/>
    <line x1="27" y1="34" x2="50" y2="34" stroke="#2ea043" stroke-width="1" opacity="0.4"/>
    <line x1="61" y1="30" x2="92" y2="30" stroke="#2ea043" stroke-width="1" opacity="0.5"/>
    <line x1="61" y1="34" x2="88" y2="34" stroke="#2ea043" stroke-width="1" opacity="0.4"/>
    <!-- glow on top -->
    <rect x="19" y="22" width="82" height="4" rx="3" fill="#2ea043" opacity="0.12"/>
    <!-- arrow up = growth -->
    <path d="M97 68 L97 48" stroke="#3fb950" stroke-width="2" stroke-linecap="round" opacity="0.8"/>
    <polygon points="97,44 93,51 101,51" fill="#3fb950" opacity="0.8"/>
  </svg>`,

  Specialist: `<svg viewBox="0 0 120 90" xmlns="http://www.w3.org/2000/svg">
    <!-- wrench -->
    <g transform="translate(35,45) rotate(-45)">
      <rect x="-4" y="-24" width="8" height="32" rx="2" fill="none" stroke="#2ea043" stroke-width="1.5" opacity="0.7"/>
      <rect x="-8" y="-28" width="16" height="8" rx="3" fill="none" stroke="#2ea043" stroke-width="1.3" opacity="0.7"/>
      <rect x="-2" y="8" width="4" height="6" rx="1" fill="#2ea043" opacity="0.5"/>
    </g>
    <!-- screwdriver -->
    <g transform="translate(75,40) rotate(30)">
      <rect x="-2.5" y="-30" width="5" height="38" rx="1.5" fill="none" stroke="#3fb950" stroke-width="1.3" opacity="0.7"/>
      <rect x="-5" y="-34" width="10" height="7" rx="2" fill="none" stroke="#3fb950" stroke-width="1.1" opacity="0.6"/>
      <rect x="-1.5" y="8" width="3" height="12" rx="0.5" fill="#3fb950" opacity="0.5"/>
    </g>
    <!-- sparkle dots -->
    <circle cx="60" cy="20" r="2" fill="#2ea043" opacity="0.8"/>
    <circle cx="55" cy="30" r="1" fill="#3fb950" opacity="0.6"/>
    <circle cx="65" cy="28" r="1.5" fill="#2ea043" opacity="0.5"/>
    <circle cx="60" cy="65" r="2" fill="#3fb950" opacity="0.4"/>
    <!-- connecting arc -->
    <path d="M46 52 Q60 42 74 52" fill="none" stroke="#2ea043" stroke-width="1" stroke-dasharray="3,2" opacity="0.4"/>
  </svg>`,

  /* ── Per-product overrides (by product ID) ─ */

  'zap-001': `<svg viewBox="0 0 120 90" xmlns="http://www.w3.org/2000/svg">
    <!-- Lightning bolt -->
    <polygon points="68,10 45,50 62,50 52,80 80,38 62,38" fill="none" stroke="#3fb950" stroke-width="1.8" stroke-linejoin="round" opacity="0.9"/>
    <polygon points="68,10 45,50 62,50 52,80 80,38 62,38" fill="#2ea043" opacity="0.08"/>
    <!-- energy rings -->
    <circle cx="60" cy="45" r="30" fill="none" stroke="#2ea043" stroke-width="0.7" opacity="0.2" stroke-dasharray="4,4"/>
    <circle cx="60" cy="45" r="20" fill="none" stroke="#2ea043" stroke-width="0.5" opacity="0.15" stroke-dasharray="3,3"/>
    <!-- sparks -->
    <circle cx="25" cy="25" r="1.5" fill="#3fb950" opacity="0.7"/>
    <circle cx="95" cy="30" r="1.5" fill="#3fb950" opacity="0.5"/>
    <circle cx="20" cy="65" r="1"   fill="#2ea043" opacity="0.6"/>
    <circle cx="100" cy="65" r="1"  fill="#2ea043" opacity="0.4"/>
  </svg>`,

  'notion-001': `<svg viewBox="0 0 120 90" xmlns="http://www.w3.org/2000/svg">
    <!-- dashboard grid -->
    <rect x="15" y="15" width="40" height="28" rx="3" fill="none" stroke="#2ea043" stroke-width="1.3" opacity="0.7"/>
    <rect x="65" y="15" width="40" height="28" rx="3" fill="none" stroke="#2ea043" stroke-width="1.3" opacity="0.5"/>
    <rect x="15" y="52" width="90" height="25" rx="3" fill="none" stroke="#3fb950" stroke-width="1.3" opacity="0.7"/>
    <!-- inner content marks -->
    <line x1="22" y1="25" x2="48" y2="25" stroke="#2ea043" stroke-width="1.2" opacity="0.5"/>
    <line x1="22" y1="31" x2="42" y2="31" stroke="#2ea043" stroke-width="1" opacity="0.35"/>
    <line x1="22" y1="37" x2="46" y2="37" stroke="#2ea043" stroke-width="1" opacity="0.35"/>
    <rect x="72" y="22" width="26" height="14" rx="2" fill="#2ea043" opacity="0.15"/>
    <line x1="22" y1="60" x2="95" y2="60" stroke="#3fb950" stroke-width="1" opacity="0.4"/>
    <line x1="22" y1="66" x2="80" y2="66" stroke="#3fb950" stroke-width="1" opacity="0.3"/>
    <line x1="22" y1="70" x2="70" y2="70" stroke="#3fb950" stroke-width="1" opacity="0.25"/>
  </svg>`,

  /* ── Fallback ────────────────────────────── */
  _default: `<svg viewBox="0 0 120 90" xmlns="http://www.w3.org/2000/svg">
    <rect x="25" y="20" width="70" height="50" rx="5" fill="none" stroke="#2ea043" stroke-width="1.5" opacity="0.6"/>
    <line x1="25" y1="35" x2="95" y2="35" stroke="#2ea043" stroke-width="0.8" opacity="0.4"/>
    <rect x="32" y="42" width="22" height="20" rx="2" fill="#2ea043" opacity="0.15"/>
    <rect x="60" y="42" width="28" height="8"  rx="2" fill="#2ea043" opacity="0.15"/>
    <rect x="60" y="54" width="20" height="8"  rx="2" fill="#2ea043" opacity="0.1"/>
    <circle cx="85" cy="22" r="2" fill="#3fb950" opacity="0.7"/>
    <circle cx="91" cy="22" r="2" fill="#2ea043" opacity="0.5"/>
    <circle cx="79" cy="22" r="2" fill="#2ea043" opacity="0.35"/>
  </svg>`
};

/**
 * Get SVG illustration for a product
 * Stamps a unique suffix on any gradient IDs to prevent SVG ID collision
 * when multiple illustrations render on the same page.
 */
let _illustrationCounter = 0;
function getIllustration(productId, category) {
  const svg = ILLUSTRATIONS[productId]
      || ILLUSTRATIONS[category]
      || ILLUSTRATIONS['_default'];
  // Make gradient/filter IDs unique to avoid cross-SVG collisions
  const uid = 'il' + (++_illustrationCounter);
  return svg.replace(/id="([^"]+)"/g, `id="${uid}-$1"`)
            .replace(/url\(#([^)]+)\)/g, `url(#${uid}-$1)`);
}

/* ── Icon-code → illustration resolver ──────────────────────
   Covers the semantic string codes used in products.json
   after emoji removal (e.g. 'automation', 'sop', 'ai' ...)    */
const ICON_CODE_MAP = {
  automation:   'Automation',
  operations:   'Operations',
  integration:  'Automation',
  sop:          'Operations',
  ai:           'AI & Copy',
  analytics:    'Productivity',
  copy:         'AI & Copy',
  mobile:       'Productivity',
  productivity: 'Productivity',
  growth:       'Specialist',
  strategy:     'Specialist',
  learning:     'Learning',
  launch:       'Automation',
  ideas:        'AI & Copy',
  writing:      'AI & Copy',
  tools:        'Operations',
  docs:         'Operations',
  product:      'Operations',
  hot:          'Specialist',
  coupon:       'Specialist',
};

// Patch getIllustration to resolve icon codes too
const _origGetIllustration = getIllustration;
function getIllustration(productId, category) {
  // Try direct lookup first
  let svg = ILLUSTRATIONS[productId] || ILLUSTRATIONS[category];
  // If not found, try icon-code mapping
  if (!svg && ICON_CODE_MAP[productId]) svg = ILLUSTRATIONS[ICON_CODE_MAP[productId]];
  if (!svg && ICON_CODE_MAP[category])  svg = ILLUSTRATIONS[ICON_CODE_MAP[category]];
  if (!svg) svg = ILLUSTRATIONS['_default'] || ILLUSTRATIONS['Operations'];
  const uid = 'il' + (++_illustrationCounter);
  return svg.replace(/id="([^"]+)"/g, `id="${uid}-$1"`)
            .replace(/url\(#([^)]+)\)/g, `url(#${uid}-$1)`);
}
